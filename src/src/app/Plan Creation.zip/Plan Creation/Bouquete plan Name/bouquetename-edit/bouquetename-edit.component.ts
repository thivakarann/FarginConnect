import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FarginServiceService } from '../../../service/fargin-service.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { BouquetenameUpdate } from '../../../fargin-model/fargin-model.module';

@Component({
  selector: 'app-bouquetename-edit',
  templateUrl: './bouquetename-edit.component.html',
  styleUrl: './bouquetename-edit.component.css'
})
export class BouquetenameEditComponent implements OnInit {
  getadminname = JSON.parse(localStorage.getItem('adminname') || '');
  Adminid = JSON.parse(localStorage.getItem('adminid') || '');
  myForm!: FormGroup;
  id: any;
  details: any;
  detailss: any;
  Broadcastername: any;
  PlanName: any;
  databundle: any;
  bData: any;
  Broadcasters: any;
  bundle: any;


  constructor(
    public Editdetails: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog

  ) { this.detailss = this.data.value; }
  ngOnInit(): void {

   console.log(this.detailss);
   
    this.id = this.data.value.boqCreationId;
    this.Broadcastername = this.data.value.bundleChannel.bundleChannelId;
   
    this.PlanName = this.data.value.bouquetName;

    this.Editdetails.BoucatenamesActive().subscribe((res: any) => {
      this.details = res.response;
      for (let index = 0; index < this.details.length; index++) {
        const element = this.details[index];
        if (element.bundleChannelId == this.Broadcastername) {
           this.databundle = element.broadCasterName
  
          }
        }
    });


    this.myForm = new FormGroup({
      bundleChannelId: new FormControl('', Validators.required),
      bouquetName: new FormControl('', Validators.required),
    });

  }
  getdata(event:any)
  {
    
    this.bData = event.target.value;
    for (let index = 0; index < this.data.value.length; index++) {
      const element = this.data.value[index];
      if (element.broadCasterName == this.bData) {
         this.bundle = element.bundleChannelId
     
    console.log(this.dataSet);
        }
      }
  }
  dataSet(dataSet: any) {
    throw new Error('Method not implemented.');
  }

  get bouquetName() {
    return this.myForm.get('bouquetName')

  }

  get bundleChannelId() {
    return this.myForm.get('bundleChannelId')

  }

  submit() {
    let submitModel: BouquetenameUpdate = {
      bundleChannelId: this.bundle || this.Broadcastername,
      boqCreationId: this.id,
      bouquetName: this.bouquetName?.value,
      modifiedBy: this.getadminname
    }

    this.Editdetails.Bouquetenameupdatae(submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
        this.dialog.closeAll();
        window.location.reload();
      }
      else {
        this.toastr.error(res.errorMessage);
      }
    })
  }


}
