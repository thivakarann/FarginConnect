import { Component, OnInit } from '@angular/core';
import { FarginServiceService } from '../../service/fargin-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { BankPrimaryStatus } from '../../fargin-model/fargin-model.module';
import { Dialog } from '@angular/cdk/dialog';
import { MatDialog } from '@angular/material/dialog';
import { ApprovalForBankComponent } from '../approval-for-bank/approval-for-bank.component';
import { CommentsForApprovalComponent } from '../comments-for-approval/comments-for-approval.component';
import { EntityBankaddComponent } from '../entity-bankadd/entity-bankadd.component';
import { EntityBankeditComponent } from '../entity-bankedit/entity-bankedit.component';
import { log } from 'console';
import { settlement } from '../../Fargin Model/fargin-model/fargin-model.module';

@Component({
  selector: 'app-entity-view',
  templateUrl: './entity-view.component.html',
  styleUrl: './entity-view.component.css'
})
export class EntityViewComponent implements OnInit {
  id: any;
  details: any;
  detaislone: any;
  bankdetails: any;
  KYCDetails: any;
  isChecked: boolean = false;
  qrCode: any;
  currentPage: any = 1
  refundValue: any;
  Viewall: any;
  viewdata: any;
  accountid: any;
  activeTab : string = 'events';

  constructor(
    public MerchantView: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private ActivateRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.ActivateRoute.queryParams.subscribe((param: any) => {
      this.id = param.Alldata;
    });

    this.MerchantView.EntityViewbyid(this.id).subscribe((res: any) => {
      this.details = res.response;
      this.detaislone = res.response.merchantpersonal;
      this.bankdetails = res.response.merchantbank;
      this.KYCDetails = res.response.merchantdocument;
      this.accountid = res.response.merchantpersonal.accountId;
      console.log(this.accountid);
      this.postrenewal()
      // console.log(this.details);
      console.log(this.detaislone);
      console.log(this.bankdetails);
      console.log(this.KYCDetails);
    })

    this.MerchantView.Entityrefund(this.id).subscribe((res: any) => {
      console.log(res);
      this.refundValue = res.response;
    })

    // this.MerchantView.Entityrefund(this.id).subscribe((res:any)=>{
    //   console.log(res);
    //   this.refundValue=res.response;
    // })
  }
  selectTab(tab: string): void {
    this.activeTab = tab;
  }

  clearFilters(): void {
    console.log('Filters cleared');
  }
  postrenewal() {
    let submitModel: settlement = {
      accountId: this.accountid,
      pageNo: "",
      size: "",
      query: "",
      dateRange: "",
      status: "",
    }
    console.log(submitModel);

    this.MerchantView.Entitysettlement(submitModel).subscribe((res: any) => {
      console.log(res);
      this.Viewall = JSON.parse(res?.response);
      this.viewdata = this.Viewall?.data?.content;
      console.log(this.viewdata);
    })
  }

  viewpayout(id: any) {
    console.log(id);
    this.router.navigate([`/dashboard/settlement-view/${id}`], {
      queryParams: { value: id },
    });
  }

  onSubmit(event: MatSlideToggleChange, id: any) {
    this.isChecked = event.checked;

    let submitModel: BankPrimaryStatus = {
      primaryAccountStatus: this.isChecked ? 0 : 1,
    };

    this.MerchantView.BankprimaryStatus(id, submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage)
      }
      else {
        this.toastr.error(res.responseMessage)
      }
    })


  }
  qrLink(id: any) {
    this.MerchantView.EntityQrGenerate(this.id).subscribe((res: any) => {
      this.qrCode = res.responseMessage;
      console.log(this.qrCode);
      if (res.responseMessage) {
        this.toastr.success('Link Generated Successfully!')
        setTimeout(() => {
          window.location.reload()
        }, 1000);
      }
      else {
        this.toastr.error('Failed To Generate Link!')
      }
    })
  }

  BankApproval(id: any) {
    this.dialog.open(ApprovalForBankComponent, {
      enterAnimationDuration: "1000ms",
      exitAnimationDuration: "1000ms",
      data: { value: id }
    })
  }

  BankComments(id: any) {
    this.dialog.open(CommentsForApprovalComponent, {
      enterAnimationDuration: "1000ms",
      exitAnimationDuration: "1000ms",
      data: { value: id }
    })
  }

  addbank(id: any) {
    this.dialog.open(EntityBankaddComponent, {
      disableClose: true,
      enterAnimationDuration: "1000ms",
      exitAnimationDuration: "1000ms",
      data: { value: id }
    })
  }

  editbank(id: any) {
    this.dialog.open(EntityBankeditComponent, {
      disableClose: true,
      enterAnimationDuration: "1000ms",
      exitAnimationDuration: "1000ms",
      data: { value: id }
    })
  }

}
