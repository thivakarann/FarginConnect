import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../../service/fargin-service.service';
import { documentupdate } from '../../../Fargin Model/fargin-model/fargin-model.module';

@Component({
  selector: 'app-edit-bussinessdocument',
  templateUrl: './edit-bussinessdocument.component.html',
  styleUrl: './edit-bussinessdocument.component.css'
})
export class EditBussinessdocumentComponent {
  fourthFormGroup!: FormGroup;
  selectElement4: any;
  kycValue: any;
  errorMessage: any;
  close: any;
  documentdata: any;
  getadminname = JSON.parse(localStorage.getItem('adminname') || '');
  merchantDocumentId: any;
  docNumbers: any;

  constructor(
    public service: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    private _formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {

    this.documentdata = this.data.value;
    console.log(this.documentdata);
    this.merchantDocumentId = this.data.value.merchantId.merchantDocumentId

    this.docNumbers=this.data.value.docNumber

    this.service.activeViewall().subscribe((res: any) => {
      this.kycValue = res.response;
      console.log(this.kycValue);
    })


    this.fourthFormGroup = this._formBuilder.group({
      kycCategoryId: ['', Validators.required],
      docNumber: [''],
     
    })

  }

  get kycCategoryId() {
    return this.fourthFormGroup.get('kycCategoryId')
  }

  get docNumber() {
    return this.fourthFormGroup.get('docNumber')
  }

 
  docProofChange(event: any) {
    this.selectElement4 = event.target.value;
    console.log(this.selectElement4);
    const docNumbers = this.fourthFormGroup.get('docNumber');
    docNumbers?.clearValidators();
    if (this.selectElement4 === 'Aadhar') {
      docNumbers?.setValidators([Validators.required, Validators.pattern("^[0-9]{12}$")]); // 12 digits for Aadhar
    } else if (this.selectElement4 === 'Pancard') {
      docNumbers?.setValidators([Validators.required, Validators.pattern("^[A-Za-z]{5}[0-9]{4}[A-Za-z]$")]); // PAN format
    } else if (this.selectElement4 === 'Voter Id Proof') {
      docNumbers?.setValidators([Validators.required, Validators.pattern("^[A-Z]{3}[0-9]{7}$")]); // Voter ID format
    } else if (this.selectElement4 === 'Passport') {
      docNumbers?.setValidators([Validators.required, Validators.pattern("^[A-Za-z0-9]{8,15}$")]); // Passport format
    } else if (this.selectElement4 === 'Driving License') {
      docNumbers?.setValidators([Validators.required, Validators.pattern("^(([A-Z]{2}[0-9]{2})( )|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$")]); // Driving license format
    }
    docNumbers?.updateValueAndValidity();
  }

  docSubmit() {

    let submitModel:documentupdate={
      merchantDocumentId: this.merchantDocumentId,
      kycCategoryId: this.kycCategoryId?.value,
      docNumber: this.docNumber?.value,
      modifiedBy: this.getadminname
    }
   
    this.service.documentEdit(submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
      } else {
        this.toastr.error(res.responseMessage);
      }
    });
  }
}
