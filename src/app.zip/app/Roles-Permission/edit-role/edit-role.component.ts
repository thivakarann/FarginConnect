import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { ActivatedRoute } from '@angular/router';
import { subpermission, updaterole } from '../../fargin-model/fargin-model.module';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrl: './edit-role.component.css'
})
export class EditRoleComponent implements OnInit {
  editRoleForm: any = FormGroup;
  getRoleName: any;
  @ViewChild('select') select: any = MatSelect;
  @ViewChild('selects') selects: any = MatSelect;
  allSelected = false;
  allSelected1 = false;
  getPerValue: any;
  getSubValue: any;
  permissionValue: any;
  values2: any[] = [];
  getRoleId: any;
  subpermissionValue:any;
  errorMessage: any;
  values: any[] = [];
  entityname: any = localStorage.getItem('entityname')
  updateValue: any;

  constructor(private dialog: MatDialog, private service: FarginServiceService, 
    private fb: FormBuilder,public activeRouter: ActivatedRoute,@Inject(MAT_DIALOG_DATA) public data: any,private toastr:ToastrService) { }

  ngOnInit(): void {

    this.service.viewallPermission().subscribe((res: any) => {
      console.log(res);
      if (res.flag == 1) {
        this.permissionValue = res.response;
        this.permissionValue.forEach((element: any) => {
          this.values2.push({
            value: element.permissionId, viewValue: element.permissions
          })
          console.log(this.values2);

        });
      }

    })


    this.editRoleForm = this.fb.group({
      roleName: ['', Validators.required],
      merchantPermission: ['', Validators.required],
      merchantSubPermission: ['', Validators.required]
    })

 

    this.activeRouter.params.subscribe((param: any) => {
      this.getRoleId = param.role;
      this.getRoleId = this.data.role;
      console.log('getRoleName ' + this.getRoleId);
    });
  
    this.activeRouter.params.subscribe((param: any) => {
      this.getRoleName = param.roleName;
      this.getRoleName = this.data.roleName;
      console.log('getRoleName ' + this.getRoleName);
    });
  

    this.activeRouter.params.subscribe((param: any) => {
      this.getPerValue = param.per;
      this.getPerValue = this.data.per;
      console.log('getPerValue ' + this.getPerValue);
    });

    this.activeRouter.params.subscribe((param: any) => {
      this.getSubValue = param.sub;
      this.getSubValue = this.data.sub;
      console.log('getSubValue ' + this.getSubValue);
    });
    
  }

  sendPermissionId(id: any) {
    console.log(id);
    let submitModel: subpermission = {
      permissionIds: id,
    }
    this.service.subpermissionValue(submitModel).subscribe((res: any) => {
      this.subpermissionValue = res.response;
      console.log(this.subpermissionValue);
      this.subpermissionValue.forEach((element: any) => {
        this.values.push({
          value: element.subPermissionId, viewValue: element.subPermissions, viewValues: element.merchantPermission.permissions
        });
        console.log(this.values);
        
      });
    })
  }


  get roleName() {
    return this.editRoleForm.get('roleName')
  }

  get merchantPermission() {
    return this.editRoleForm.get('merchantPermission')
  }

  get merchantSubPermission() {
    return this.editRoleForm.get('merchantSubPermission')
  }


  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  toggleAllSelection1() {
    if (this.allSelected1) {
      this.selects.options.forEach((item: MatOption) => item.select());
    } else {
      this.selects.options.forEach((item: MatOption) => item.deselect());
    }
  }
  submit(){
    let submitModel:updaterole={
      modifiedBy: this.entityname,
      roleName: this.roleName.value,
      merchantPermission: this.merchantPermission.value,
      merchantSubPermission: this.merchantSubPermission.value
    }
    this.service.updateRoles(this.getRoleId,submitModel).subscribe((res:any)=>{
      this.updateValue = res.response;
      console.log(this.updateValue);
      if (res.flag == 1) {
        this.toastr.success("Role has been Updated Successfully");
        this.dialog.closeAll();
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
      else {
        this.toastr.error(res.responseMessage);
      }
    })
  }
}
