import { Component } from '@angular/core';
import { SessionServiceService } from './Session Service/session-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'FarginConnectAdmin';
  timeout: number;

  constructor(private sessionTimerService: SessionServiceService) {
    this.timeout = this.sessionTimerService.getTimeoutInMinutes();
  }


  updateTimeout(): void {
    this.sessionTimerService.updateTimeout(this.timeout);
  }
}
