import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { ViewServiceticketComponent } from './servicetickets/view-serviceticket/view-serviceticket.component';
import { AddServiceticketComponent } from './servicetickets/add-serviceticket/add-serviceticket.component';
import { EditServiceticketComponent } from './servicetickets/edit-serviceticket/edit-serviceticket.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ViewTicketcommentComponent } from './servicetickets/view-ticketcomment/view-ticketcomment.component';
import { ViewRoleComponent } from './Roles-Permission/view-role/view-role.component';
import { AddRoleComponent } from './Roles-Permission/add-role/add-role.component';
import { ViewSetupboxComponent } from './main-master/setupbox/view-setupbox/view-setupbox.component';
import { EditSetupboxComponent } from './main-master/setupbox/edit-setupbox/edit-setupbox.component';
import { ViewBeneficiaryComponent } from './Beneficiary/view-beneficiary/view-beneficiary.component';
import { AddadminComponent } from './Admin/addadmin/addadmin.component';
import { ViewadminComponent } from './Admin/viewadmin/viewadmin.component';
import { EditadminComponent } from './Admin/editadmin/editadmin.component';
import { AddBeneficiaryComponent } from './Beneficiary/add-beneficiary/add-beneficiary.component';
import { EditBeneficiaryComponent } from './Beneficiary/edit-beneficiary/edit-beneficiary.component';
import { ViewRegionComponent } from './main-master/region/view-region/view-region.component';
import { ViewRouteComponent } from './main-master/route/view-route/view-route.component';
import { TransactionViewComponent } from './Transaction/transaction-view/transaction-view.component';
import { ViewwithdrawalComponent } from './Quickwithdrawal/viewwithdrawal/viewwithdrawal.component';
import { ChannelConfigurationComponent } from './Channels-Packages/channel-configuration/channel-configuration.component';
import { PlanConfigurationComponent } from './Channels-Packages/plan-configuration/plan-configuration.component';
import { StreetViewComponent } from './main-master/route/street-view/street-view.component';
import { AreaViewComponent } from './main-master/route/area-view/area-view.component';
import { ViewBulkComponent } from './main-master/setupbox/setupbox-bulkupload/view-bulk/view-bulk.component';
import { DuesComponent } from './dues/dues.component';
import { ReturnsuccessComponent } from './Onetimesetup/returnsuccess/returnsuccess.component';
import { ReturnfailureComponent } from './Onetimesetup/returnfailure/returnfailure.component';
import { ProfileComponent } from './profile/profile.component';
import { SetupComponent } from './Onetimesetup/setup/setup.component';
import { ResponseBulkComponent } from './main-master/setupbox/setupbox-bulkupload/response-bulk/response-bulk.component';
import { DuesSuccessComponent } from './dues/dues-success/dues-success.component';
import { DuesFailureComponent } from './dues/dues-failure/dues-failure.component';


const routes: Routes = [

  { path: 'login-page', component: LoginPageComponent },
  { path: '', redirectTo: '/login-page', pathMatch: 'full' },


  { path: 'edit-setupbox', component: EditSetupboxComponent },

  { path: 'street-view', component: StreetViewComponent },

  { path: 'area-view', component: AreaViewComponent },

  { path: 'return-success', component: ReturnsuccessComponent },

  { path: 'return-failure', component: ReturnfailureComponent },

  { path: 'dues-success', component: DuesSuccessComponent },

  { path: 'dues-failure', component: DuesFailureComponent },



  {
    path: 'dashboard', component: DashboardComponent, children: [

      { path: 'view-serviceticket', component: ViewServiceticketComponent },

      { path: 'add-serviceticket', component: AddServiceticketComponent },

      { path: 'view-role', component: ViewRoleComponent },

      { path: 'view-setupbox', component: ViewSetupboxComponent },

      { path: 'view-beneficiary', component: ViewBeneficiaryComponent },

      { path: 'view-admin', component: ViewadminComponent },

      { path: 'add-admin', component: AddadminComponent },

      { path: 'edit-admin/:id', component: EditadminComponent },

      { path: 'add-beneficiary', component: AddBeneficiaryComponent },

      { path: 'edit-beneficiary/:id', component: EditBeneficiaryComponent },

      { path: 'view-region', component: ViewRegionComponent },

      { path: 'view-route', component: ViewRouteComponent },

      { path: 'transaction-view', component: TransactionViewComponent },

      { path: 'viewwithdrawal', component: ViewwithdrawalComponent },

      { path: 'channel-configuration', component: ChannelConfigurationComponent },

      { path: 'plan-configuration', component: PlanConfigurationComponent },

      { path: 'view-bulk', component: ViewBulkComponent },

      { path: 'dues', component: DuesComponent },

      { path: 'view-profile', component: ProfileComponent },

      { path: 'setup', component: SetupComponent },

      { path: 'response-bulk', component: ResponseBulkComponent }




    ]
  },





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
