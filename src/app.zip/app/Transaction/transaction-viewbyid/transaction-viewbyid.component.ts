import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FarginServiceService } from '../../service/fargin-service.service';

@Component({
  selector: 'app-transaction-viewbyid',
  templateUrl: './transaction-viewbyid.component.html',
  styleUrl: './transaction-viewbyid.component.css'
})
export class TransactionViewbyidComponent {
viewdata: any;
viewdata1: any;
transactiondata: any;
constructor(private router: Router, private service: FarginServiceService, private dialog: MatDialog) { }

cancel(){
  this.dialog.closeAll()
}

}
