import { Component, Inject, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { routeupdate, updatesetupbox } from '../../../fargin-model/fargin-model.module';
import { FarginServiceService } from '../../../service/fargin-service.service';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'app-edit-route',
  templateUrl: './edit-route.component.html',
  styleUrl: './edit-route.component.css'
})
export class EditRouteComponent {
  routeformGroup: any = FormGroup;
  viewData: any;
  entityname: any = localStorage.getItem('entityname')
  boxnumber: any;
  routeId: any;
  updatevalue: any;
  employee: any;
  merchantId: any = localStorage.getItem('merchantId');
  @ViewChild('select') select: any = MatSelect;
  @ViewChild('selects') selects: any = MatSelect;
  allSelected = false;
  allSelected1 = false;
  streetname: any[] = [];
  areaname: any[] = [];
  filteredProviders: any[] = this.streetname;
  filteredProviders1: any[] = this.areaname;
  showstreet: any;
  showarea: any;
  streetData: any;
  areaData: any;
  constructor(private dialog: MatDialog, private service: FarginServiceService,
    private toastr: ToastrService, private fb: FormBuilder, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {


    this.viewData = this.data.value
    console.log(this.viewData);
    
    this.streetData=this.data.value.streetName
    console.log(this.streetData);

    this.areaData=this.data.value.area
    console.log(this.areaData);
    
    
    this.routeId = this.data.value.routeId;

    this.service.activeEmployees(this.merchantId).subscribe((res: any) => {
      this.employee = res.response;
      console.log(this.employee);
    })


    this.routeformGroup = this.fb.group({
      merchantAdminId: ['', Validators.required],
      beatRole: ['', Validators.required],
      streetName: ['', Validators.required],
      area: ['', Validators.required]
    })

    this.service.viewstreetName().subscribe((res: any) => {
      this.streetname = res.response;
      console.log(this.streetname);
    });

    this.service.viewareaName().subscribe((res: any) => {
      this.areaname = res.response;
      console.log(this.areaname);
    })


  }

  get merchantAdminId() {
    return this.routeformGroup.get('merchantAdminId')
  }


  get streetName() {
    return this.routeformGroup.get('streetName')
  }

  get area() {
    return this.routeformGroup.get('area')
  }

  get beatRole() {
    return this.routeformGroup.get('beatRole')
  }


  streetId(id: any) {
    console.log(id);
    this.showstreet = id
  }

  areaId(id: any) {
    console.log(id);
    this.showarea = id
  }



  onInputChange(event: any) {
    const searchInput = event.target.value.toLowerCase();
    this.filteredProviders = this.streetname.filter(({ showstreet }) => {
      const prov = showstreet.toLowerCase();
      return prov.includes(searchInput);
    });
  }

  onOpenChange(searchInput: any) {
    searchInput.value = "";
    this.filteredProviders = this.streetname;
  }


  onInputChange1(event: any) {
    const searchInput = event.target.value.toLowerCase();
    this.filteredProviders1 = this.areaname.filter(({ showarea }) => {
      const prov = showarea.toLowerCase();
      return prov.includes(searchInput);
    });
  }

  onOpenChange1(searchInput: any) {
    searchInput.value = "";
    this.filteredProviders1 = this.areaname;
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  toggleAllSelection1() {
    if (this.allSelected1) {
      this.selects.options.forEach((item: MatOption) => item.select());
    } else {
      this.selects.options.forEach((item: MatOption) => item.deselect());
    }
  }

  submit() {
    let submitModel: routeupdate = {
      merchantAdminId: this.merchantAdminId.value,
      streetName: this.streetName.value||null,
      area: this.area.value||null,
      beatRole: this.beatRole.value,
      merchantId:this.merchantId
    }
    this.service.routeedit(this.routeId, submitModel).subscribe((res: any) => {
      this.updatevalue = res.response;
      console.log(this.updatevalue);
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
        this.dialog.closeAll()
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
      else {
        this.toastr.error(res.responseMessage)
      }
    })
  }
}
