import { Component, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-area-view',
  templateUrl: './area-view.component.html',
  styleUrl: './area-view.component.css'
})
export class AreaViewComponent {
areaValue: any;
constructor(private dialog: MatDialog,
  @Inject(MAT_DIALOG_DATA) public data: any) { }

ngOnInit(): void {
  console.log(this.data.value);
  this.areaValue = this.data.value
}

back() {
  this.dialog.closeAll()
}
}
