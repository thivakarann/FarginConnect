import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../../service/fargin-service.service';

@Component({
  selector: 'app-street-view',
  templateUrl: './street-view.component.html',
  styleUrl: './street-view.component.css'
})
export class StreetViewComponent implements OnInit {
  streetValue: any;
  constructor(private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    console.log(this.data.value);
    this.streetValue = this.data.value
  }

  back() {
    this.dialog.closeAll()
  }
}
