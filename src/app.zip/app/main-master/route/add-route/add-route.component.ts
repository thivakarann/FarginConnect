import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../../service/fargin-service.service';
import { retry } from 'rxjs';
import { route } from '../../../fargin-model/fargin-model.module';
import { log } from 'console';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'app-add-route',
  templateUrl: './add-route.component.html',
  styleUrl: './add-route.component.css'
})
export class AddRouteComponent implements OnInit {
  streetname: any[] = [];
  areaname: any[] = [];
  routeformGroup: any = FormGroup;
  setupBoxNumber: any;
  providers = new FormControl();
  allProviders: any[] = [{ PROV: "aaa" }, { PROV: "aab" }, { PROV: "aac" }];
  filteredProviders: any[] = this.streetname;
  filteredProviders1: any[] = this.areaname;
  employee: any;
  routeValues: any;
  fullname: any = localStorage.getItem('fullname');
  @ViewChild('select') select: any = MatSelect;
  @ViewChild('selects') selects: any = MatSelect;
  allSelected = false;
  allSelected1 = false;
  streetvalue: any;
  showstreet: any;
  showarea: any;
  merchantId: any = localStorage.getItem('merchantId');


  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService, private fb: FormBuilder,) {
  }

  ngOnInit(): void {
    this.routeformGroup = this.fb.group({
      beatRole: ['', Validators.required],
      merchantAdminId: ['', Validators.required],
      streetName: ['', Validators.required],
      area: ['', Validators.required]
    });

    this.service.activeEmployees(this.merchantId).subscribe((res: any) => {
      this.employee = res.response;
      console.log(this.employee);
    })

    this.service.viewstreetName().subscribe((res: any) => {
      this.streetname = res.response;
      console.log(this.streetname);
    });

    this.service.viewareaName().subscribe((res: any) => {
      this.areaname = res.response;
      console.log(this.areaname);
    })


  }



  get merchantAdminId() {
    return this.routeformGroup.get('merchantAdminId')
  }

  get streetName() {
    return this.routeformGroup.get('streetName')
  }

  get area() {
    return this.routeformGroup.get('area')
  }

  get beatRole() {
    return this.routeformGroup.get('beatRole')
  }


  streetId(id: any) {
    console.log(id);
    this.showstreet = id
  }

  areaId(id: any) {
    console.log(id);
    this.showarea = id
  }



  onInputChange(event: any) {
    const searchInput = event.target.value.toLowerCase();
    this.filteredProviders = this.streetname.filter(({ showstreet }) => {
      const prov = showstreet.toLowerCase();
      return prov.includes(searchInput);
    });
  }

  onOpenChange(searchInput: any) {
    searchInput.value = "";
    this.filteredProviders = this.streetname;
  }


  onInputChange1(event: any) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.showarea.filter = filterValue.trim().toLowerCase();
  }

  // applyFilter(event: Event) {
   

   
  // }

  onOpenChange1(searchInput: any) {
    searchInput.value = "";
    this.filteredProviders1 = this.areaname;
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  toggleAllSelection1() {
    if (this.allSelected1) {
      this.selects.options.forEach((item: MatOption) => item.select());
    } else {
      this.selects.options.forEach((item: MatOption) => item.deselect());
    }
  }

  submit() {
    let submitModel: route = {
      streetName: this.streetName.value,
      area: this.area.value,
      merchantAdminId: this.merchantAdminId.value,
      beatRole: this.beatRole.value,
      createdBy: this.fullname,
      merchantId: this.merchantId
    }
    this.service.routecreate(submitModel).subscribe((res: any) => {
      this.routeValues = res.response;
      console.log(this.routeValues);

      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
        this.dialog.closeAll()
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
      else {
        this.toastr.error(res.responseMessage)
      }
    })
  }
}
