import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, map, observable } from 'rxjs';
import { Addadmins, addbeneficiary, Addonetime, editbenificiary, employeeStatus, postsetupbox, primaryStatus, roles, roleStatus, route, routests, routeupdate, setupStatus, Statusadmin, subpermission, Tickets, Upadteadmins, updaterole, updatesetupbox } from '../fargin-model/fargin-model.module';

@Injectable({
  providedIn: 'root'
})
export class FarginServiceService {
  updateTicketimage: any;

  constructor(private http: HttpClient,
    private router: Router) { }

  private readonly basePath = 'http://64.227.149.125:8085/'; //Basepath

  // login
  private readonly entitylogin = 'merchant/entitylogin';

  //Service Tickets
  private readonly viewallTicket = 'tickets/viewbymerchant/';
  private readonly addTicket = 'tickets/create';
  private readonly viewTicketImage = 'tickets/viewimage/';
  private readonly editTicket = 'tickets/updateticket';
  private readonly editImage = 'tickets/updatedocument';


  //Roles and permission
  private readonly viewallRole = 'merchantrole/viewmerchantrole/'
  private readonly viewRoles = 'merchantrole/viewpermissionandsubpermmission/';
  private readonly getallPermission = 'merchantpermission/getallpermissions';
  private readonly getSubpermission = 'merchantsubpermisssion/getpermissionlist';
  private readonly createrole = 'merchantrole/create';
  private readonly updateRole = 'merchantrole/updaterole/';
  private readonly statusRole = 'merchantrole/updatestatus';


  //setupbox
  private readonly setupboxViewall = 'setupbox/viewAll';
  private readonly setupboxStatus = 'setupbox/updateStatus';
  private readonly setupboxadd = 'setupbox/create';
  private readonly setupboxedit = 'setupbox/update';
  private readonly setupboxmerchantid = 'setupbox/viewByMerchant/';

  private readonly addadmin = 'merchantadminlogin/create';
  private readonly viewadmin = 'merchantadminlogin/viewall'
  private readonly viewbyidadmin = 'merchantadminlogin/viewbyid/';
  private readonly editadmin = 'merchantadminlogin/updateadmin/';
  private readonly statusadmin = 'merchantadminlogin/updatestatus/';

  //beneficiary
  private readonly Beneficiaryadd = 'employeebeneficiary/create';
  private readonly BeneficiaryView = 'employeebeneficiary/viewmerchant/';
  private readonly BeneficiaryemployeeView = 'merchantadminlogin/viewbyid/';
  private readonly BeneficiaryemployeeEdit = 'employeebeneficiary/update/';
  private readonly BeneficiaryViewbyid = 'employeebeneficiary/viewbyid/';
  private readonly BeneficiaryStatus = 'employeebeneficiary/updateactive/';
  private readonly BeneficiaryPrimary = 'employeebeneficiary/updateprimary/';

  //region
  private readonly regionviewall = 'region/viewAllRegion';
  private readonly regionViewactive = 'region/viewOnlyActive';
  private readonly regionViewbyid = 'region/viewByService/';

  //Route configuration
  private readonly routeviewall = 'route/viewAll';
  private readonly routeCreate = 'route/create';
  private readonly routeEdit = 'route/update/';
  private readonly viewStreetName = 'customer/viewallStreetName';
  private readonly viewAreaName = 'customer/viewallArea';
  private readonly routeStatus = 'route/activeInactive/';
  private readonly activeEmployee = 'merchantadminlogin/merchantActiveStatus/';
  private readonly routemerchantid='route/viewByMerchant/';

  //transaction
  private readonly transaction = 'paymentHistory/viewByMerchant/';

  //Channel configuration
  private readonly channelConfiguration = 'alcotchannel/viewOnlyActive';

  //Plan configuration
  private readonly planConfiguration = 'bouquetCreation/viewOnlyActive';

  //service
  private readonly serviceActive = 'serviceProvider/viewActive';

  //setupbox bulk upload
  private readonly bulkUploadsetupbox = 'setupbox/uploadsetupboxnumber'
  private readonly bulkUploadView = 'setupbox/getuploaddatabymerchant/'
  private readonly bulkuploadResponse = 'setupbox/uploadList/'
  private readonly bulkuploadbyId = 'setupbox/response/'


  //One Time Setup fee
  private readonly addonetime = 'merchantpay/makepayment';
  private readonly pgmode = 'pgmode/activepg';
  private readonly createcost = 'merchantpay/createorder/';
  private readonly initiatecost = 'merchantpay/initiate/';
  private readonly getonetimesucces = 'transhistory/getbyid/';

  loginError = new Subject();

  gettoken = localStorage.getItem('token');
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    X_ACCESS_TOKEN: `Bearer ${this.gettoken ? (localStorage.getItem('token') || '') : null
      }`,
  });

  headersMultipart = new HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    X_ACCESS_TOKEN: `Bearer ${this.gettoken ? (localStorage.getItem('token') || '') : null
      }`,
  });

  options = { headers: this.headers };
  optionsMultipart = { headers: this.headersMultipart };

  getEntityLogin(email: string, password: string) {
    const credentialBody = {
      contactEmail: email,
      password: password,
    };

    return this.http.post(`${this.basePath}${this.entitylogin}`, credentialBody).subscribe((res: any) => {
      if (res.flag == 1) {
        localStorage.setItem('token', (res.response.login_history.merchantModel.jwtResponse.X_ACCESS_TOKEN));
        localStorage.setItem('merchantId', (res.response.login_history?.merchantModel?.merchantId));
        localStorage.setItem('entityname', (res.response.login_history?.merchantModel?.entityName));
        localStorage.setItem('merchantname', (res.response.login_history?.merchantModel?.merchantLegalName));
        localStorage.setItem('mobilenumber', (res.response.login_history?.merchantModel?.contactMobile));
        localStorage.setItem('address', (res.response.login_history?.merchantModel?.billingAddress));
        localStorage.setItem('area', (res.response.login_history?.merchantModel?.area));
        localStorage.setItem('pincode', (res.response.login_history?.merchantModel?.zipcode));
        localStorage.setItem('city', (res.response.login_history?.merchantModel?.city));
        localStorage.setItem('fullname', (res.response.login_history?.merchantModel?.createdBy));
        localStorage.setItem(
          'stateName',
          res.response.login_history?.merchantModel?.stateName
        );

        localStorage.setItem(
          'emailOtpVerificationStatus',
          res.response.login_history?.merchantModel
            ?.emailOtpVerificationStatus
        );
        localStorage.setItem(
          'smsOtpVerificationstatus',

          res.response.login_history?.merchantModel?.smsOtpVerificationstatus
        );
        localStorage.setItem(
          'technicalPayStatus',

          res.response.login_history?.merchantModel?.technicalPayStatus
        );
        localStorage.setItem(
          'technicalAmount',

          res.response.login_history?.merchantModel?.merchantPlanModel
            ?.technicalAmount
        );
        localStorage.setItem(
          'merchantPlanId',

          res.response.login_history?.merchantModel?.merchantPlanModel
            ?.merchantPlanId
        );

        localStorage.setItem(
          'modifiedDateTime',
          res.response.login_history?.modifiedDateTime
        );
        location.href = '/dashboard';
      }
      else {
        this.loginError.next(res.responseMessage);
      }

    });
  }

  viewTicket(id: any) {
    return this.http.get(
      `${this.basePath}${this.viewallTicket}${id}`,
      this.options
    );
  }

  addserviceTicket(FormData: FormData) {
    return this.http.post(
      `${this.basePath}${this.addTicket}`,
      FormData,
      this.optionsMultipart
    );
  }

  viewticketImage(id: string) {
    return this.http.get(`${this.basePath}${this.viewTicketImage}${id}`, {
      ...this.options,
      ...{ responseType: 'blob' },
    });
  }

  updateTickets(model: Tickets) {
    return this.http.put(
      `${this.basePath}${this.editTicket}`,
      model,
      this.options
    );
  }

  editTicketImage(formData: FormData) {
    return this.http.put(
      `${this.basePath}${this.editImage}`,
      formData,
      this.optionsMultipart
    );
  }

  viewRole(id: any) {
    return this.http.get(`${this.basePath}${this.viewRoles}${id}`, this.options)
  }

  viewallPermission() {
    return this.http.get(`${this.basePath}${this.getallPermission}`, this.options)
  }

  subpermissionValue(model: subpermission) {
    return this.http.post(`${this.basePath}${this.getSubpermission}`, model, this.options)
  }
  createroles(model: roles) {
    return this.http.post(`${this.basePath}${this.createrole}`, model, this.options)
  }

  updateRoles(id: any, model: updaterole) {
    return this.http.put(`${this.basePath}${this.updateRole}${id}`, model, this.options)
  }

  statusRoles(model: roleStatus) {
    return this.http.put(`${this.basePath}${this.statusRole}`, model, this.options)
  }

  getallRole(id: any) {
    return this.http.get(`${this.basePath}${this.viewallRole}${id}`, this.options)
  }

  setupboxView() {
    return this.http.get(`${this.basePath}${this.setupboxViewall}`, this.options)
  }

  setupboxstatus(model: setupStatus) {
    return this.http.put(`${this.basePath}${this.setupboxStatus}`, model, this.options)
  }

  setupboxCreate(model: postsetupbox) {
    return this.http.post(`${this.basePath}${this.setupboxadd}`, model, this.options)
  }

  setupboxEdit(model: updatesetupbox) {
    return this.http.put(`${this.basePath}${this.setupboxedit}`, model, this.options)
  }

  setupboxbyid(id: any) {
    return this.http.get(`${this.basePath}${this.setupboxmerchantid}${id}`, this.options)
  }

  // Admin Method
  addadmins(model: Addadmins) {
    return this.http.post(
      `${this.basePath}${this.addadmin}`,
      model,
      this.options
    );
  }
  viewadmins() {
    return this.http.get(
      `${this.basePath}${this.viewadmin}`,
      this.options
    );
  }
  viewbyidadmins(id: any) {
    return this.http.get(
      `${this.basePath}${this.viewbyidadmin}${id}`,
      this.options
    );
  }
  editadmins(id: any, model: Upadteadmins) {
    return this.http.put(
      `${this.basePath}${this.editadmin}${id}`,
      model,
      this.options
    );
  }
  statusadmins(id: any, model: Statusadmin) {
    return this.http.put(`${this.basePath}${this.statusadmin}${id}`, model, this.options)
  }

  beneficiaryAdd(model: addbeneficiary) {
    return this.http.post(`${this.basePath}${this.Beneficiaryadd}`, model, this.options)
  }

  BeneficiaryViewall(id: any) {
    return this.http.get(`${this.basePath}${this.BeneficiaryView}${id}`, this.options);
  }

  BeneficiaryEmployeeView(id: any) {
    return this.http.get(`${this.basePath}${this.BeneficiaryemployeeView}${id}`, this.options);
  }

  BeneficiaryEmployeeEdit(id: any, model: editbenificiary) {
    return this.http.put(`${this.basePath}${this.BeneficiaryemployeeEdit}${id}`, model, this.options)
  }

  BeneficiaryViewbyId(id: any) {
    return this.http.get(`${this.basePath}${this.BeneficiaryViewbyid}${id}`, this.options)
  }

  Beneficiarystatus(id: any, model: employeeStatus) {
    return this.http.put(`${this.basePath}${this.BeneficiaryStatus}${id}`, model, this.options)
  }

  BeneficiaryPrimarystatus(id: any, model: primaryStatus) {
    return this.http.put(`${this.basePath}${this.BeneficiaryPrimary}${id}`, model, this.options)
  }

  regionview() {
    return this.http.get(`${this.basePath}${this.regionviewall}`, this.options)
  }

  routeViewall() {
    return this.http.get(`${this.basePath}${this.routeviewall}`, this.options)
  }

  routecreate(model: route) {
    return this.http.post(`${this.basePath}${this.routeCreate}`, model, this.options)
  }

  routeedit(id: any, model: routeupdate) {
    return this.http.put(`${this.basePath}${this.routeEdit}${id}`, model, this.options)
  }

  viewstreetName() {
    return this.http.get(`${this.basePath}${this.viewStreetName}`, this.options)
  }

  viewareaName() {
    return this.http.get(`${this.basePath}${this.viewAreaName}`, this.options)
  }

  routestatus(id: any, model: routests) {
    return this.http.put(`${this.basePath}${this.routeStatus}${id}`, model, this.options)
  }

  routemerchantId(id:any) {
    return this.http.get(`${this.basePath}${this.routemerchantid}${id}`, this.options)
  }

  activeEmployees(id: any) {
    return this.http.get(`${this.basePath}${this.activeEmployee}${id}`, this.options)
  }

  transactionView(id: any) {
    return this.http.get(`${this.basePath}${this.transaction}${id}`, this.options)
  }

  regionViewActive() {
    return this.http.get(`${this.basePath}${this.regionViewactive}`, this.options)
  }

  channelconfiguration() {
    return this.http.get(`${this.basePath}${this.channelConfiguration}`, this.options)
  }

  planconfiguration() {
    return this.http.get(`${this.basePath}${this.planConfiguration}`, this.options)
  }

  serviceactive() {
    return this.http.get(`${this.basePath}${this.serviceActive}`, this.options)
  }

  regionViewByid(id: any) {
    return this.http.get(`${this.basePath}${this.regionViewbyid}${id}`, this.options);
  }

  bulkUploadSetupbox(formData: any[]) {
    return this.http.post(`${this.basePath}${this.bulkUploadsetupbox}`, formData, this.options)
  }

  bulkuploadViewall(id: any) {
    return this.http.get(`${this.basePath}${this.bulkUploadView}${id}`, this.options);
  }

  bulkuploadresponse(id: any) {
    return this.http.get(`${this.basePath}${this.bulkuploadResponse}${id}`, this.options)
  }

  bulkuploadById(id: any) {
    return this.http.get(`${this.basePath}${this.bulkuploadbyId}${id}`, this.options)
  }

  //One time setup
  addonetimes(model: Addonetime) {
    return this.http.post(
      `${this.basePath}${this.addonetime}`,
      model,
      this.options
    );
  }

  pgmodes() {
    return this.http.get(`${this.basePath}${this.pgmode}`, this.options);
  }
  
  getCreateCost(id: any, id1: any) {
    return this.http.get(
      `${this.basePath}${this.createcost}${id}/${id1}`,
      this.options
    );
  }

  getinitateCost(id: any, id1: any) {
    return this.http.get(
      `${this.basePath}${this.initiatecost}${id}/${id1}`,
      this.options
    );
  }

  getonetimesuccess(id: any) {
    return this.http.get(
      `${this.basePath}${this.getonetimesucces}${id}`,
      this.options
    );
  }



}
