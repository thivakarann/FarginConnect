import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import FileSaver from 'file-saver';
import { Workbook } from 'exceljs';

@Component({
  selector: 'app-plan-configuration',
  templateUrl: './plan-configuration.component.html',
  styleUrl: './plan-configuration.component.css'
})
export class PlanConfigurationComponent {
  plan: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  dataSource: any;
  responseDataListnew:any[]=[];
  response:any[]=[]
  displayedColumns: any[] = 
  [
    "boqCreationId",
    "broadCasterName",
    "bouquetName",
     ];

  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService) { }
 
ngOnInit(): void {
 this.service.planconfiguration().subscribe((res:any)=>{
  this.plan=res.response;
  console.log(this.plan);
  this.dataSource = new MatTableDataSource(this.plan?.reverse())
  this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;
 })
}

applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();
  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  }
}

exportexcel() {
  let sno = 1;
  this.responseDataListnew = [];
  this.plan.forEach((element: any) => {
    this.response = [];
    this.response.push(sno);
    this.response.push(element?.bundleChannel?.broadCasterName);
    this.response.push(element?.bouquetName);
    sno++;
    this.responseDataListnew.push(this.response);
  });
  this.excelexportCustomer();
}

excelexportCustomer() {
  const header = [
    "S.No",
    "BroadCaster Name",
    "BroadCaster Plan",
  ]


  const data = this.responseDataListnew;
  let workbook = new Workbook();
  let worksheet = workbook.addWorksheet('Plan Details Reports');
  // Blank Row
  worksheet.addRow([]);
  let headerRow = worksheet.addRow(header);
  headerRow.font = { bold: true };
  // Cell Style : Fill and Border
  headerRow.eachCell((cell, number) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFFFFFFF' },
      bgColor: { argb: 'FF0000FF' },

    }

    cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
  });

  data.forEach((d: any) => {
    // console.log("row loop");
    let row = worksheet.addRow(d);
    let qty = row.getCell(1);
    let qty1 = row.getCell(2);
    let qty2 = row.getCell(3);
   
    qty.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    qty1.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    qty2.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
   

  }
  );
  worksheet.getColumn(1).protection = { locked: true, hidden: true }
  worksheet.getColumn(2).protection = { locked: true, hidden: true }
  worksheet.getColumn(3).protection = { locked: true, hidden: true }
  workbook.xlsx.writeBuffer().then((data: any) => {
    let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    FileSaver.saveAs(blob, 'Plan Details Reports.xlsx');
  });
}


}
