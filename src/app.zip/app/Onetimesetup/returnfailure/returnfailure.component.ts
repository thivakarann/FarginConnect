import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-returnfailure',
  templateUrl: './returnfailure.component.html',
  styleUrl: './returnfailure.component.css'
})
export class ReturnfailureComponent {
  constructor(private router:Router)
  {
    
  }
  Returnurl() {
    this.router.navigateByUrl(`/login-page`);
 
 
  }
}
