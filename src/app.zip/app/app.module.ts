import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { LoadingInterceptor } from './Loading Interceptor/loading.interceptor.spec';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatCommonModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatGridListModule } from '@angular/material/grid-list';
import { DashboardComponent } from './dashboard/dashboard.component';
import {MatSortModule} from '@angular/material/sort';
import { AddServiceticketComponent } from './servicetickets/add-serviceticket/add-serviceticket.component';
import { ViewServiceticketComponent } from './servicetickets/view-serviceticket/view-serviceticket.component';
import { EditServiceticketComponent } from './servicetickets/edit-serviceticket/edit-serviceticket.component';
import { ViewTicketcommentComponent } from './servicetickets/view-ticketcomment/view-ticketcomment.component';
import { ViewTicketdescriptionComponent } from './servicetickets/view-ticketdescription/view-ticketdescription.component';
import { ViewTicketimageComponent } from './servicetickets/view-ticketimage/view-ticketimage.component';
import { ViewRoleComponent } from './Roles-Permission/view-role/view-role.component';
import { AddRoleComponent } from './Roles-Permission/add-role/add-role.component';
import { EditRoleComponent } from './Roles-Permission/edit-role/edit-role.component';
import {MatSelectModule} from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AddSetupboxComponent } from './main-master/setupbox/add-setupbox/add-setupbox.component';
import { ViewSetupboxComponent } from './main-master/setupbox/view-setupbox/view-setupbox.component';
import { EditSetupboxComponent } from './main-master/setupbox/edit-setupbox/edit-setupbox.component';
import { AddBeneficiaryComponent } from './Beneficiary/add-beneficiary/add-beneficiary.component';
import { ViewBeneficiaryComponent } from './Beneficiary/view-beneficiary/view-beneficiary.component';
import { EditBeneficiaryComponent } from './Beneficiary/edit-beneficiary/edit-beneficiary.component'; 
import { AddadminComponent } from './Admin/addadmin/addadmin.component';
import { ViewadminComponent } from './Admin/viewadmin/viewadmin.component';
import { EditadminComponent } from './Admin/editadmin/editadmin.component';
import { ViewRegionComponent } from './main-master/region/view-region/view-region.component';
import { ViewRouteComponent } from './main-master/route/view-route/view-route.component';
import { AddRouteComponent } from './main-master/route/add-route/add-route.component';
import { EditRouteComponent } from './main-master/route/edit-route/edit-route.component';
import { TransactionViewComponent } from './Transaction/transaction-view/transaction-view.component';
import { TransactionViewbyidComponent } from './Transaction/transaction-viewbyid/transaction-viewbyid.component';
import {MatTabsModule} from '@angular/material/tabs';
import { ViewwithdrawalComponent } from './Quickwithdrawal/viewwithdrawal/viewwithdrawal.component';
import { AddwithdrawalComponent } from './Quickwithdrawal/addwithdrawal/addwithdrawal.component';
import { ChannelConfigurationComponent } from './Channels-Packages/channel-configuration/channel-configuration.component';
import { PlanConfigurationComponent } from './Channels-Packages/plan-configuration/plan-configuration.component';
import { StreetViewComponent } from './main-master/route/street-view/street-view.component';
import { AreaViewComponent } from './main-master/route/area-view/area-view.component';
import { ViewPermissionComponent } from './Roles-Permission/view-permission/view-permission.component';
import { ViewSubpermissionComponent } from './Roles-Permission/view-subpermission/view-subpermission.component';
import { CreateBulkComponent } from './main-master/setupbox/setupbox-bulkupload/create-bulk/create-bulk.component';
import { ViewBulkComponent } from './main-master/setupbox/setupbox-bulkupload/view-bulk/view-bulk.component';
import { ResponseBulkComponent } from './main-master/setupbox/setupbox-bulkupload/response-bulk/response-bulk.component';
import { DuesComponent } from './dues/dues.component';
import { SetupComponent } from './Onetimesetup/setup/setup.component';
import { DuesSuccessComponent } from './dues/dues-success/dues-success.component';
import { DuesFailureComponent } from './dues/dues-failure/dues-failure.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    SpinnerComponent,
    AddServiceticketComponent,
    ViewServiceticketComponent,
    EditServiceticketComponent,
    DashboardComponent,
    ViewTicketimageComponent,
    ViewTicketcommentComponent,
    ViewTicketdescriptionComponent,
    ViewRoleComponent,
    AddRoleComponent,
    EditRoleComponent,
    AddSetupboxComponent,
    ViewSetupboxComponent,
    EditSetupboxComponent,
    AddBeneficiaryComponent,
    ViewBeneficiaryComponent,
    EditBeneficiaryComponent,
    AddadminComponent,
    ViewadminComponent,
    EditadminComponent,
    ViewRegionComponent,
    ViewRouteComponent,
    AddRouteComponent,
    EditRouteComponent,
    TransactionViewComponent,
    TransactionViewbyidComponent,
    ViewwithdrawalComponent,
    AddwithdrawalComponent,
    ChannelConfigurationComponent,
    PlanConfigurationComponent,
    StreetViewComponent,
    AreaViewComponent,
    ViewPermissionComponent,
    ViewSubpermissionComponent,
    CreateBulkComponent,
    ViewBulkComponent,
    ResponseBulkComponent,
    DuesComponent,
    SetupComponent,
    DuesSuccessComponent,
    DuesFailureComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    MatMenuModule,
    MatTableModule,
    MatCardModule,
    MatPaginatorModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatChipsModule,
    MatCommonModule,
    MatDatepickerModule,
    MatDialogModule,
    MatPaginatorModule,
    MatInputModule,
    MatToolbarModule,
    MatStepperModule,
    MatGridListModule,
    MatSortModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTabsModule

  ],
  providers: [{
    provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
