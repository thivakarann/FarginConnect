export interface Tickets {
  readonly description: any;
  readonly subject: any;
  readonly ticketStatus: any;
  readonly raiseTicketId: any;
}

export interface subpermission {
  readonly permissionIds: any;

}

export interface roles {
  readonly roleName: any;
  readonly merchantPermission: any;
  readonly merchantSubPermission: any;
  readonly createdBy: any;
  readonly merchantId: any;
}

export interface updaterole {
  readonly modifiedBy: any;
  readonly roleName: any;
  readonly merchantPermission: any;
  readonly merchantSubPermission: any;
}

export interface roleStatus {
  readonly merchantRoleId: any;
  readonly status: any;
}

export interface setupStatus{
  readonly status:any;
  readonly stbId:any;
}

export interface postsetupbox{
  readonly setupBoxNumber:any;
  readonly createdBy:any;
  readonly regionId:any;
  readonly serviceId:any;
  readonly merchantId:any
}

export interface updatesetupbox{
  readonly setupBoxNumber:any;
  readonly modifiedBy:any;
  readonly stbId:any;
  readonly regionId:any;
  readonly serviceId:any;
}

export interface Addadmins
{
  readonly adminName:any;
  readonly email:any;
  readonly gender:any;
  readonly age:any;
  readonly mobileNumber:any;
  readonly address:any;
  readonly countryName:any;
  readonly stateName:any;
  readonly cityName:any;
  readonly pincodeName:any;
  readonly createdBy:any;
  readonly password:any;
  readonly reqDeviceType:any
  readonly merchantId:any
}
 
export interface Upadteadmins
{
  readonly adminName:any;
  readonly email:any;
  readonly gender:any;
  readonly age:any;
  readonly mobileNumber:any;
  readonly address:any;
  readonly countryName:any;
  readonly stateName:any;
  readonly cityName:any;
  readonly pincodeName:any;
  readonly modifiedBy:any;
 
}
export interface Statusadmin{
  readonly accountStatus:any;
}

export interface addbeneficiary{
  readonly employeeId:any;
  readonly bankName:any;
  readonly accountNumber:any;
  readonly accountHolderName:any;
  readonly emailAddress:any;
  readonly ifscCode:any;
  readonly accountType:any;
  readonly mobileNumber:any;
  readonly createdBy:any;
  readonly branchName:any;
  readonly upiId:any;
  readonly type:any;
  readonly confirmAccountNumber:any;
  readonly merchantId:any;
}
export interface editbenificiary{
  readonly bankName:any;
  readonly accountNumber:any;
  readonly accountHolderName:any;
  readonly emailAddress:any;
  readonly ifscCode:any;
  readonly accountType:any;
  readonly mobileNumber:any;
  readonly createdBy:any;
  readonly branchName:any;
  readonly upiName:any;
  readonly type:any;
}

export interface employeeStatus{
  readonly activeStatus:any;
}

export interface primaryStatus{
  readonly primaryAccountStatus:any;
}

export interface route{
  readonly streetName:any;
  readonly area:any;
  readonly merchantAdminId:any;
  readonly beatRole:any;
  readonly createdBy:any;
  readonly merchantId:any;
}

export interface routeupdate{
  readonly merchantAdminId:any;
  readonly streetName:any;
  readonly area:any;
  readonly beatRole:any;
  readonly merchantId:any
}

export interface routests{
  readonly activeStatus:any
}

export interface Addonetime
{
  readonly merchantId:any;
  readonly paidAmount:any
}