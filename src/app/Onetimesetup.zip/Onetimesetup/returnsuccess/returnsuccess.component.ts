import { Component } from '@angular/core';
import { FarginServiceService } from '../../service/fargin-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-returnsuccess',
  templateUrl: './returnsuccess.component.html',
  styleUrl: './returnsuccess.component.css'
})
export class ReturnsuccessComponent {
  payId: any;
  data: any;
  constructor(private activatedroute:ActivatedRoute,public service:FarginServiceService,private router:Router){
    this.activatedroute.queryParams.subscribe((params:any)=>{
          this.payId=params.payId
    })
  }


  ngOnInit(): void {
    this.service.getonetimesuccess(this.payId).subscribe((res:any)=>{
        this.data=res.response
    })
  }
  Returnurl() {
    this.router.navigateByUrl(`/login-page`);
 
 
  }
}
