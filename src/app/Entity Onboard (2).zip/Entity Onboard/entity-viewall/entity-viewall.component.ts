import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { FarginServiceService } from '../../service/fargin-service.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ElementRef } from '@angular/core';

@Component({
  selector: 'app-entity-viewall',
  templateUrl: './entity-viewall.component.html',
  styleUrl: './entity-viewall.component.css'
})
export class EntityViewallComponent {
  dataSource!: MatTableDataSource<any>;
  displayedColumns: string[] = [
    'merchantId',
    'entityName',
    'merchantLegalName',
    'businessCategoryModel',
    'referenceNo',
    'contactEmail',
    'contactMobile',
    'website',
    'View',
    'createdBy',
    'createdDatetime',
    'modifiedBy',
    'modifiedDatetime',


  ];
  viewall: any;
  @ViewChild('tableContainer') tableContainer!: ElementRef;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  isChecked: boolean = false;
  errorMessage: any;
  roleId: any = localStorage.getItem('roleId')
  getdashboard: any[] = [];
  actions:any;
  valueEntityAdd: boolean=true;
  valueEntityExport: boolean=true;
  valueEntityView: boolean=true;
  
  constructor(
    public service: FarginServiceService,
    private router: Router,
    private toastr: ToastrService
  ) { }
  ngOnInit(): void {
    this.service.rolegetById(this.roleId).subscribe({
      next: (res: any) => {
        console.log(res);

        if (res.responseMessage == "Success") {
          this.getdashboard = res.response?.subPermission;
          console.log(this.getdashboard);
          if(this.roleId==1){
            this.valueEntityAdd = false;
            this.valueEntityExport = false;
            this.valueEntityView = false;
          }
          else{
          for (let datas of this.getdashboard) {

            this.actions = datas.subPermissionId;
            console.log(this.actions + 'this.roles');

            if (this.actions == '9') {
              this.valueEntityAdd = false;
            }

            if (this.actions == '10') {
              this.valueEntityExport = false;
            }

            if (this.actions == '11') {
              this.valueEntityView = false;
            }
          }
        }
        }
        else {
          this.errorMessage = res.responseMessage;
        }
      }
    })

    this.service.EntityViewall().subscribe((res: any) => {
      this.viewall = res.response;
      this.viewall.reverse();
      this.dataSource = new MatTableDataSource(this.viewall);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      console.log(this.viewall);
    });
  }


  add() {
    this.router.navigateByUrl('dashboard/entity-add');
  }



  Viewdata(id: any) {
    this.router.navigate([`dashboard/entity-view/${id}`], {
      queryParams: { Alldata: id },
    });
    console.log(id);
  }





  exportexcel() {

  }



  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
