import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import * as XLSX from 'xlsx';
import { FarginServiceService } from '../../../../service/fargin-service.service';

@Component({
  selector: 'app-create-bulk',
  templateUrl: './create-bulk.component.html',
  styleUrl: './create-bulk.component.css'
})
export class CreateBulkComponent implements OnInit {
setupformGroup: any=FormGroup;
  file: any;
  ExcelData: any;
  parsedJson: any;
  arrayExcel: any;
  uploadFiles: any;
  merchantId: any = localStorage.getItem('merchantId');
  entityname: any = localStorage.getItem('entityname')

  constructor(private dialog: MatDialog, 
    private service: FarginServiceService, 
    private toastr: ToastrService,
  private fb:FormBuilder,
) { }
  ngOnInit(): void {
    this.setupformGroup=this.fb.group({
      uploadFile:['',Validators.required]
    })
    
  }
  get uploadFile(){
    return this.setupformGroup.get('uploadFile')
  }



uploadBulkFile(event: any) {
  console.log('got');
  this.file = event.target.files[0];
  console.log(this.file);
  let fileReader = new FileReader();
  fileReader.readAsBinaryString(this.file);
  fileReader.onload = (e) => {
    const rABS = !!fileReader.readAsArrayBuffer;
    var workbook = XLSX.read(fileReader.result, {
      type: rABS ? 'binary' : 'string',
    });
    console.log(workbook);
    var sheetname = workbook.SheetNames;
    this.ExcelData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetname[0]]);
    console.log(this.ExcelData);
    this.parsedJson = this.ExcelData;
    console.log('With Parsed JSON :', this.parsedJson);
    this.arrayExcel = this.parsedJson;
    console.log(this.arrayExcel);
  };
}


onSubmit(){
  this.service.bulkUploadSetupbox(this.merchantId,this.entityname,this.arrayExcel).subscribe((res: any) => {
    this.uploadFiles = res.response;
    console.log(this.uploadFiles);
    
   if (res.flag == 1) {
     this.toastr.success(res.responseMessage)
     this.dialog.closeAll();
     setTimeout(() => {
       window.location.reload();
     }, 500);
   } 
   else if (res.flag == 2) {
     this.toastr.success(res.responseMessage)
     this.dialog.closeAll();
     setTimeout(() => {
       window.location.reload();
     }, 500);
   } 
   else
    this.toastr.error(res.responseMessage)
  });
}
}
