import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Workbook } from 'exceljs';
import FileSaver from 'file-saver';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../../../service/fargin-service.service';
import { AddSetupboxComponent } from '../../add-setupbox/add-setupbox.component';
import { CreateBulkComponent } from '../create-bulk/create-bulk.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { setupStatus } from '../../../../fargin-model/fargin-model.module';
import moment from 'moment';
import { EditSetupboxComponent } from '../../edit-setupbox/edit-setupbox.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-bulk',
  templateUrl: './view-bulk.component.html',
  styleUrl: './view-bulk.component.css'
})
export class ViewBulkComponent implements OnInit {
  dataSource: any;
  merchantId: any = localStorage.getItem('merchantId');
  displayedColumns: any[] = ["stbId", "setupBoxNumber", "MSO", "Region", "status", "action", "CreatedBy", "createdAt"];
  bulkdata: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  isChecked: any;
  responseDataListnew: any[] = [];
  response: any[] = []
  date1: any;
  constructor(private router: Router,
    private dialog: MatDialog,
     private service: FarginServiceService,
      private toastr: ToastrService) { }

  ngOnInit(): void {
    this.service.bulkuploadViewall(this.merchantId).subscribe((res: any) => {
      this.bulkdata = res.response;
      console.log(this.bulkdata);
      this.dataSource = new MatTableDataSource(this.bulkdata?.reverse())
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  openExcel() {
    let sno = 1;
    this.responseDataListnew = [];
    this.excelexportDetails();
  }
  excelexportDetails() {
    const header = [ "setupBoxNumber", "serviceProviderName","stateName"]
    const data = this.responseDataListnew;
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Edit Sheet');
    let headerRow = worksheet.addRow(header);
    headerRow.font = { bold: true };
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' },
        bgColor: { argb: 'FF0000FF' },
      }
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    });

    data.forEach((d: any) => {
      let row = worksheet.addRow(d);
      let qty = row.getCell(1);
      let qty1 = row.getCell(2);
      let qty2=row.getCell(3);
   
      qty.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty1.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty2.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    });
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      FileSaver.saveAs(blob, 'SetupBox.csv');
    });
  }


  onSubmit(event: MatSlideToggleChange, id: any) {
    console.log(id);
    this.isChecked = event.checked;
    let submitModel: setupStatus = {
      status: this.isChecked ? 1 : 0,
      stbId: id
    };
    this.service.setupboxstatus(submitModel).subscribe((res: any) => {
      console.log(res);
      this.toastr.success(res.responseMessage);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    });
  }
  
  exportexcel() {
    let sno = 1;
    this.responseDataListnew = [];
    this.bulkdata.forEach((element: any) => {
      this.response = [];
      this.response.push(sno);
      this.response.push(element?.setupBoxNumber);
      this.response.push(element?.service?.serviceProviderName)
      this.response.push(element?.regionEntity?.stateName);
      this.response.push(element?.createdBy);
      let createdate = element?.createdAt;
      this.date1 = moment(createdate).format('DD/MM/yyyy-hh:mm a').toString();
      this.response.push(this.date1);
      sno++;
      this.responseDataListnew.push(this.response);
    });
    this.excelexportCustomer();
  }

  excelexportCustomer() {
    const header = [
      "S.No",
      "Setup Box Number",
      "MSO",
      "Region",
      "Created By",
      "Created At",
    ]


    const data = this.responseDataListnew;
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Setupbox Reports');
    // Blank Row
    worksheet.addRow([]);
    let headerRow = worksheet.addRow(header);
    headerRow.font = { bold: true };
    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' },
        bgColor: { argb: 'FF0000FF' },

      }

      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    });

    data.forEach((d: any) => {
      // console.log("row loop");
      let row = worksheet.addRow(d);
      let qty = row.getCell(1);
      let qty1 = row.getCell(2);
      let qty2 = row.getCell(3);
      let qty3 = row.getCell(4);
      let qty4 = row.getCell(5);
      let qty5 = row.getCell(6);


      qty.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty1.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty2.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty3.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty4.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty5.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }

    }
    );
    worksheet.getColumn(1).protection = { locked: true, hidden: true }
    worksheet.getColumn(2).protection = { locked: true, hidden: true }
    worksheet.getColumn(3).protection = { locked: true, hidden: true }
    workbook.xlsx.writeBuffer().then((data: any) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      FileSaver.saveAs(blob, 'Setupbox Reports.xlsx');
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  create() {
    this.dialog.open(CreateBulkComponent, {
      disableClose: true,
      width: '80vw',// Use percentage to make it responsive
      maxWidth: '500px',
      height: 'auto',
      enterAnimationDuration: '1000ms',
      exitAnimationDuration: '1000ms',
    });
  }

  open() {
    this.dialog.open(AddSetupboxComponent, {
      disableClose: true,
      width: '80vw',// Use percentage to make it responsive
      maxWidth: '500px',
      height:'auto',
      enterAnimationDuration: '1000ms',
      exitAnimationDuration: '1000ms',
    });
  }

  edit(id: any) {
    this.dialog.open(EditSetupboxComponent, {
      data:{value:id},
      disableClose: true,
      width: '80vw',// Use percentage to make it responsive
      maxWidth: '600px',
      enterAnimationDuration: '1000ms',
      exitAnimationDuration: '1000ms',
    });
  }

  bulkResponse(){
    this.router.navigateByUrl('/dashboard/response-bulk')

  }

}
