import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';

@Component({
  selector: 'app-admin-terms-condition',
  templateUrl: './admin-terms-condition.component.html',
  styleUrl: './admin-terms-condition.component.css'
})
export class AdminTermsConditionComponent implements OnInit{

  dataSource:any;
  displayedColumns: string[] = ["adminId","termAndCondition","disclaimer","privacyPolicy","refundPolicy","createdBy"]
  businesscategory:any;
  showcategoryData:boolean =false;
  errorMsg: any;
  responseDataListnew: any=[];
  response: any=[];
   
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  isChecked: any;
  date1: any;
  date2:any;
  policyId: any;
  termAndCondition:any;

 
   
   
  constructor(private dialog:MatDialog,private service:FarginServiceService,private toastr:ToastrService, private router: Router,@Inject(MAT_DIALOG_DATA) private data:any) {
 
  }


  ngOnInit(): void {
    
    this.service.adminPolicyget().subscribe((res: any) => {
      if(res.flag==1){
        this.businesscategory = res.response;
        for (let i = 0; i < this.businesscategory.length; i++) {
          const element = this.businesscategory[i];
          this.policyId = element.policyId;
        console.log(this.policyId)
        this.termAndCondition = element.termAndCondition;
        console.log(this.termAndCondition)

      } 
    }  
    });


  }


  
  close() {
    window.location.reload()
  }

}