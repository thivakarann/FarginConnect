import { Component } from '@angular/core';

@Component({
  selector: 'app-onetimesetup',
  templateUrl: './onetimesetup.component.html',
  styleUrl: './onetimesetup.component.css'
})
export class OnetimesetupComponent {

}
