import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Router } from '@angular/router';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-transaction-view',
  templateUrl: './transaction-view.component.html',
  styleUrl: './transaction-view.component.css'
})
export class TransactionViewComponent implements OnInit {
  merchantid: any = localStorage.getItem('merchantid')
  dataSource: any;
  displayedColumns: any[] = ['sno', 'customername', 'transactionId', 'amount', 'paymentmethod', 'status', 'paidat', 'view',];
  transactionValue: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private router: Router, private service: FarginServiceService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.service.transactionView(this.merchantid).subscribe((res: any) => {
      this.transactionValue = res.response;
      console.log(this.transactionValue);
      this.dataSource = new MatTableDataSource(this.transactionValue?.reverse())
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  exportexcel() {
    throw new Error('Method not implemented.');
  }

}
