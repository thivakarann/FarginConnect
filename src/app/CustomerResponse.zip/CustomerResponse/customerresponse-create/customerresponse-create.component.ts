import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatOption } from '@angular/material/core';
import { Router } from '@angular/router';
import {CustomerResponse } from '../../fargin-model/fargin-model.module';
import { MatSelect } from '@angular/material/select';
import { Location } from '@angular/common';

@Component({
  selector: 'app-customerresponse-create',
  templateUrl: './customerresponse-create.component.html',
  styleUrl: './customerresponse-create.component.css'
})
export class CustomerresponseCreateComponent implements OnInit{
  merchantId: any = localStorage.getItem('merchantId');
 
  myForm!: FormGroup;
  details: any;
  customerStbId: any;
  Channels: any;
  ActivePlans: any;
  ActiveLCOP: any;
  bouquet: any;
  allSelected2: any;
  allSelected1: any;
 
  andssss: any;
  lcp: any;
  allSelected3: any;
  activequestion: any;
  @ViewChild('select3') select3: any = MatSelect;
  @ViewChild('select2') select2: any = MatSelect;

  options = [
    { value: '1', viewValue: 'Yes' },
    { value: '0', viewValue: 'No' },
  ];
  activecust: any;
  customerId: any;
question: any;
ans: any;
  questionId: any;
  constructor(
    public service: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private location:Location
  ) { }
 
 
ngOnInit(): void {
 this.service.ActiveCustomers().subscribe((res:any)=>{
  if(res.flag==1){
    this.activecust=res.response;
  }
 })
    this.service.ActiveQuestions().subscribe((res: any) => {
      if(res.flag==1){
        this.activequestion = res.response;
        console.log(this.activequestion);
       this.question=res.response.questions;
        
      }
     
    });
  
 
    this.myForm = new FormGroup({
      customer :new FormControl('', Validators.required),
      answers: new FormControl('', Validators.required),
      questions:new FormControl('',Validators.required),
      remarks: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9 ]*$'),
      ]),
    });
  }
 
 
 
  get customer() {
    return this.myForm.get('customer')
 
  }
  get answers() {
    return this.myForm.get('answers')
 
  }
  get questions() {
    return this.myForm.get('questions')
 
  }
  get remarks() {
    return this.myForm.get('remarks')
 
  }
 
  submit() {
    let submitModel: CustomerResponse = {
      remark: this.remarks?.value,
      quesId: Array.from(new Set(this.questions?.value)),
      answer: Array.from(new Set(this.answers?.value)),
      customerId: this.customer?.value
    }
 
    this.service.AddCustomerResponse(submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
      this.router.navigateByUrl('dashboard/view-customer-response')
        // setTimeout(() => {
        //   window.location.reload()
        // }, 500);
      }
      else {
        this.toastr.error(res.responseMessage);
      }
    })
  }
 
  toggleAllSelection2() {
    if (this.allSelected2) {
      this.select2.options.forEach((item: MatOption) => item.select());
    } else {
      this.select2.options.forEach((item: MatOption) => item.deselect());
    }
  }
 
  toggleAllSelection3() {
    if (this.allSelected3) {
      this.select3.options.forEach((item: MatOption) => item.select());
    } else {
      this.select3.options.forEach((item: MatOption) => item.deselect());
    }
  }
  close(){
    this.location.back()
  }
}
