import { Component, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { announceEdit, Businessadd } from '../../fargin-model/fargin-model.module';
import { FarginServiceService } from '../../service/fargin-service.service';

@Component({
  selector: 'app-edit-announcement',
  templateUrl: './edit-announcement.component.html',
  styleUrl: './edit-announcement.component.css'
})
export class EditAnnouncementComponent {
  announcementform: any = FormGroup;
  createdBy = JSON.parse(localStorage.getItem('adminname') || '');
  categoryvalue: any;
  businessCategoryIds: any;
  announcementContentEnglishs: any;
  startDates: any;
  endDates: any;
  announcementid: any;

  constructor(private dialog: MatDialog,
    private service: FarginServiceService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }


  ngOnInit(): void {
    console.log(this.data.value);
    this.announcementid=this.data.value.announcementId
    console.log(this.announcementid);
    

    this.businessCategoryIds = this.data.value.businessCategory.businessCategoryId
    this.announcementContentEnglishs = this.data.value.announcementContentEnglish
    this.startDates = this.data.value.startDate
    this.endDates = this.data.value.endDate
    this.service.BusinesscategoryKycactive().subscribe((res: any) => {
      this.categoryvalue = res.response;
    })

    this.announcementform = new FormGroup({
      businessCategoryId: new FormControl('', [Validators.required]),
      announcementContentEnglish: new FormControl('', [Validators.required]),
      startDate: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required])
    });

  }



  get businessCategoryId() {
    return this.announcementform.get('businessCategoryId');
  }

  get announcementContentEnglish() {
    return this.announcementform.get('announcementContentEnglish');
  }

  get startDate() {
    return this.announcementform.get('startDate');
  }

  get endDate() {
    return this.announcementform.get('endDate')
  }

  submit() {
    let submitModel: announceEdit = {
      announcementId: this.announcementid,
      businessCategoryId: this.businessCategoryId.value,
      announcementContentEnglish: this.announcementContentEnglish.value,
      startDate: this.startDate.value,
      endDate: this.endDate.value,
      updatedBy: this.createdBy
    };


    this.service.announcementEdit(submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage)
        window.location.reload();

      }
      else {
        this.toastr.error(res.responseMessage);
        this.dialog.closeAll()
      }

    });

  }
}
