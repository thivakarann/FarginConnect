import { Component, OnInit, ViewChild } from '@angular/core';
import { FarginServiceService } from '../../service/fargin-service.service';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { PaymentlinkResendComponent } from '../paymentlink-resend/paymentlink-resend.component';
import { Location } from '@angular/common';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-paymentlink-view',
  templateUrl: './paymentlink-view.component.html',
  styleUrl: './paymentlink-view.component.css'
})
export class PaymentlinkViewComponent implements OnInit {
  dataSource: any;
  displayedColumns: string[] = [
    'paymentId',
    'paymentlink',
    'reference',
    'expiry',
    'generatedat',
    
  ];
  id: any;
  paymentValue: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
   public location:Location, public service: FarginServiceService, private ActivateRoute: ActivatedRoute,private dialog:MatDialog
  ) { }

  ngOnInit(): void {
    this.ActivateRoute.queryParams.subscribe((param: any) => {
      this.id = param.Alldata;
    });

    this.service.paymentLinkview(this.id).subscribe((res: any) => {
      this.paymentValue = res.response;
      console.log(this.paymentValue);
      this.dataSource = new MatTableDataSource(this.paymentValue?.reverse())
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    })
  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  resendLink(id:any){
    this.dialog.open(PaymentlinkResendComponent, {
      enterAnimationDuration: "1000ms",
      exitAnimationDuration: "1000ms",
      disableClose: true,
      data: {
        value: this.id,
      }
    })
 
  }
  close(){
    this.location.back()
   }
}
