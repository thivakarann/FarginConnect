import { Component, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../../service/fargin-service.service';
import { Addfacheckkey } from '../../../Fargin Model/fargin-model/fargin-model.module';

@Component({
  selector: 'app-addfacheckkey',
  templateUrl: './addfacheckkey.component.html',
  styleUrl: './addfacheckkey.component.css',
})
export class AddfacheckkeyComponent {
  facheckkeyFormGroup: any = FormGroup;
  createdBy = JSON.parse(localStorage.getItem('adminname') || '');
  facheckkey: any;
  constructor(
    private service: FarginServiceService,
    private router: Router,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.facheckkeyFormGroup = new FormGroup({
      apiKey: new FormControl('', [Validators.required]),
      secretKey: new FormControl('', [Validators.required]),
      applicationId:new FormControl('',[Validators.required]),
      mode: new FormControl('', [Validators.required]),
      createdBy:new FormControl(''),
    });
  }

  get apiKey() {
    return this.facheckkeyFormGroup.get('apiKey');
  }
  get secretKey() {
    return this.facheckkeyFormGroup.get('secretKey');
  }
  get mode() {
    return this.facheckkeyFormGroup.get('mode');
  }
  get applicationId() {
    return this.facheckkeyFormGroup.get('applicationId');
  }
  submit() {
    let submitModel: Addfacheckkey = {
      apiKey: this.apiKey.value,
      secretKey: this.secretKey?.value,
      applicationId: this.applicationId?.value,
      mode:this.mode?.value,
      createdBy:this.createdBy
    }
    this.service.addfacheck(submitModel).subscribe((res: any) => {
      this.facheckkey = res.response;


      if (res.flag == 1) {
        this.toastr.success(res.responseMessage);
        this.dialog.closeAll()
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
      else {
        this.toastr.error(res.responseMessage)
      }
    })
  }
  cancel() {
    this.router.navigateByUrl('dashboard/view-facheck');
  }
}
