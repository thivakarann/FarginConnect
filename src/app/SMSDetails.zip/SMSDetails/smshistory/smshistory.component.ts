import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';

@Component({
  selector: 'app-smshistory',
  templateUrl: './smshistory.component.html',
  styleUrl: './smshistory.component.css'
})
export class SmshistoryComponent {
  date: any;
  categoryError: any;

  dataSource: any;
  displayedColumns: string[] = ["sno", "smsTitle", "smsTempDescription","approval","createdDateTime"]
  businesscategory: any;
  showcategoryData: boolean = false;
  errorMsg: any;
  responseDataListnew: any = [];
  response: any = [];
  merchantId: any = localStorage.getItem('merchantId')
  fullname: any = localStorage.getItem('fullname')
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  viewsms: any;
  isChecked: any;
  merchantsmsId: any;
  id: any;
FromDateRange: any;
ToDateRange: any;

  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService) { }

  ngOnInit() {


    this.service.viewsmshistorys(this.merchantId).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewsms = res.response;
        this.viewsms.reverse();
        this.dataSource = new MatTableDataSource(this.viewsms);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.showcategoryData = false;

      }
      else {
        this.errorMsg = res.responseMessage;
        this.showcategoryData = true;
      }
    });
}

applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  }
}
filterdate()
{
  this.service.viewsmsdates(this.merchantId,this.FromDateRange,this.ToDateRange).subscribe((res:any)=>
  {
    if(res.flag==1)
    {
      this.date=res.response;
      this.dataSource = new MatTableDataSource(this.date.reverse());
       
      this.dataSource.paginator=this.paginator
      this.dataSource.sort=this.sort
      this.showcategoryData = false;
    }
    else if (res.flag == 2) {
      this.showcategoryData = true;
      this.categoryError = res.responseMessage;
    } else {
      this.categoryError = res.responseMessage;
    }
  })
}
reset(){
  window.location.reload();
}


}
