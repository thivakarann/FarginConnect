import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { ActiveSms } from '../../fargin-model/fargin-model.module';
import { SmsapprovalComponent } from './smsapproval/smsapproval.component';
import { SmsviewhistoryComponent } from '../smsviewhistory/smsviewhistory.component';

@Component({
  selector: 'app-viewsms',
  templateUrl: './viewsms.component.html',
  styleUrl: './viewsms.component.css'
})
export class ViewsmsComponent {
  dataSource: any;
  displayedColumns: string[] = ["sno", "smsTitle", "smsTempDescription","approval","status","approveststatus","viewstatus"]
  businesscategory: any;
  showcategoryData: boolean = false;
  errorMsg: any;
  responseDataListnew: any = [];
  response: any = [];
  merchantId: any = localStorage.getItem('merchantId')
  fullname: any = localStorage.getItem('fullname')
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  viewsms: any;
  isChecked: any;
  merchantsmsId: any;
  id: any;
  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService) { }

  ngOnInit() {


    this.service.viewmerchantssms(this.merchantId).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewsms = res.response;
        this.viewsms.reverse();
        this.dataSource = new MatTableDataSource(this.viewsms);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.showcategoryData = false;

      }
      else {
        this.errorMsg = res.responseMessage;
        this.showcategoryData = true;
      }
    });
}

applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  }
}

onSubmit(event: MatSlideToggleChange, id: any) {
  this.isChecked = event.checked;

  let submitModel: ActiveSms = {
    smsStatus: this.isChecked ? 1 : 0,
    modifedBy:this.fullname

  };

  this.service.updateactivesstatus(id, submitModel).subscribe((res: any) => {
    console.log(res);
    this.toastr.success(res.responseMessage);
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  });
}
SmsApproval(id: any) {
  this.dialog.open(SmsapprovalComponent, {
    enterAnimationDuration: "1000ms",
    exitAnimationDuration: "1000ms",
    disableClose: true,
    data: {
      value: id,
    }
  })
}
ViewMerchantSms(id:any){
  this.merchantsmsId=id;
  this.dialog.open(SmsviewhistoryComponent, {
    enterAnimationDuration: "1000ms",
    exitAnimationDuration: "1000ms",
    disableClose: true,
    data: { value: this.id ,
      value1:this.merchantsmsId
    }
  })
}

}