import { Component } from '@angular/core';
import { FarginServiceService } from '../../service/fargin-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { Location } from '@angular/common';

@Component({
  selector: 'app-channelconfiguration-singleview',
  templateUrl: './channelconfiguration-singleview.component.html',
  styleUrl: './channelconfiguration-singleview.component.css'
})
export class ChannelconfigurationSingleviewComponent {

  id: any;
  regiondetails: any;
  alcardsdetails: any;
  regionname: any;
  ChennelName: any;
  BroadCaster: any;
  Generic: any;
  Language: any;
  Type: any;
  amount: any;

  constructor(
    public AlcartView: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    private ActivateRoute: ActivatedRoute,
    private dialog: MatDialog,
    private location:Location
  ) { }
  ngOnInit(): void {
    this.ActivateRoute.queryParams.subscribe((param: any) => {
      this.id = param.Alldata;
    });

    this.AlcartView.Alcardviewbyid(this.id).subscribe((res: any) => {
      this.alcardsdetails = res.response;
    });
  }


  Viewimage(id: any) {

  this.AlcartView.AlcartImageview(id).subscribe({
    next: (res: any) => {
      const reader = new FileReader();
      reader.readAsDataURL(res);
      reader.onloadend = () => {
      var downloadURL = URL.createObjectURL(res);
      window.open(downloadURL);
  }
}

});
  }


  close() {
    this.location.back()
  }
}
