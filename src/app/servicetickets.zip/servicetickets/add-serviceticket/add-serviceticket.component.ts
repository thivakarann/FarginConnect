import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FarginServiceService } from '../../service/fargin-service.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

class ImageSnippet {
  pending: boolean = false;
  status: string = 'init';

  constructor(public src: string, public file: File) { }
}
@Component({
  selector: 'app-add-serviceticket',
  templateUrl: './add-serviceticket.component.html',
  styleUrl: './add-serviceticket.component.css'
})
export class AddServiceticketComponent implements OnInit {
  ticketFormGroup: any = FormGroup;
  selectedFile: any = ImageSnippet;
  merchantId: any;
  ticket: any;
  merchantid:any=localStorage.getItem('merchantid')

  constructor(private service: FarginServiceService, private toastr: ToastrService,
     private formBuilder: FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.ticketFormGroup = this.formBuilder.group({
      subject: new FormControl('', [Validators.required]),
      ticketStatus: new FormControl('', [Validators.required]),
      document: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required]),
    })
  }

  numbers(event: any) {
    const charcode = (event.which) ? event.which : event.keycode;
    if (charcode > 31 && (charcode < 48 || charcode > 57)) {
      return false;
    }
    return true;
  }

  get subject() {
    return this.ticketFormGroup.get('subject')
  }
  get ticketStatus() {
    return this.ticketFormGroup.get('ticketStatus')
  }
  get document() {
    return this.ticketFormGroup.get('document')
  }
  get description() {
    return this.ticketFormGroup.get('description')
  }
 

  processFile(imageInput: any) {
    const file: File = imageInput.files[0];
    const reader = new FileReader();
    reader.addEventListener('load', (event: any) => {
      this.selectedFile = new ImageSnippet(event.target.result, file);
      this.selectedFile.pending = true;
      console.log(this.selectedFile.file);
    });
    reader.readAsDataURL(file);
  }
  save() {
    const formData = new FormData()
    formData.append('merchantId', this.merchantid);
    formData.append('subject', this.subject?.value);
    formData.append('description', this.description?.value);
    formData.append('fileImage', this.selectedFile?.file);
    formData.append('ticketStatus', this.ticketStatus?.value)
    console.log(formData);
    this.service.addserviceTicket(formData).subscribe((res: any) => {
      this.ticket = res.response
      console.log();
      if (res.flag == 1) {
        this.toastr.success(res.responseMessage)
        this.router.navigateByUrl('/dashboard/view-serviceticket')
      }
      else {
        this.toastr.error(res.responseMessage)
      }
    })

  }
  back(){
    this.router.navigateByUrl('/dashboard/view-serviceticket')
  }
  cancel(){
    this.router.navigateByUrl('/dashboard/view-serviceticket')
  }
}
