import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { FarginServiceService } from '../../service/fargin-service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-setupbox-historyview',
  templateUrl: './setupbox-historyview.component.html',
  styleUrl: './setupbox-historyview.component.css'
})
export class SetupboxHistoryviewComponent {
  merchantid: any = localStorage.getItem('merchantId');
  history: any;
  date2: any;
  date1: any;
  dataSource: any;
  displayedColumns: string[] = [
    'sno',
    'number',
     'Status',
    'modifiedBy',
    'modifiedAt',
  ];

  showcategoryData: boolean = false;
  errorMsg: any;
  responseDataListnew: any = [];
  response: any = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  customerid: any;
  setupboxhistory: any;
  id: any;
  id1:any;
  id2:any;
  STBID: any;

  constructor(
    private location: Location,
    private service: FarginServiceService,
    private activatedRoute: ActivatedRoute
  ) {}
  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((param: any) => {
      this.customerid = param.Alldata;
      this.STBID = param.Alldata1;

      // this.customerid = this.id[0].customerId.customerId;
      this.STBID = this.id[0].customerStbId
      console.log("details" + this.id)
      console.log("customerid" + this.customerid)
      console.log("STBID" + this.STBID)
  
    });

    this.service.SetupBoxHistory(this.merchantid,this.customerid,this.STBID).subscribe((res: any) => {
      if (res.flag == 1) {
        this.setupboxhistory = res.response;
        this.dataSource = new MatTableDataSource(this.setupboxhistory.reverse());
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
   
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  close() {
    this.location.back()
  }

  reload(){
    window.location.reload()
  }

}
