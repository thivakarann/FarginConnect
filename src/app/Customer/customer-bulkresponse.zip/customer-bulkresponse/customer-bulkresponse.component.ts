import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import FileSaver from 'file-saver';
import { Workbook } from 'exceljs';

@Component({
  selector: 'app-customer-bulkresponse',
  templateUrl: './customer-bulkresponse.component.html',
  styleUrl: './customer-bulkresponse.component.css'
})
export class CustomerBulkresponseComponent implements OnInit {
  dataSource: any;
  displayedColumns: any[] = ["uploadid", "totalRecord", "successCount", "failedCount", "UploadedBy", "UploadedAt", "Response"];
  merchantId: any = localStorage.getItem('merchantId');
  bulkresponse: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  responseData: any;
  responseExcelData: any = [];
  dataPush: any = [];
  valueresponse: any;
  getdashboard: any[] = [];
  actions: any;
  roleId: any = localStorage.getItem('roleId')
  constructor(
    private dialog: MatDialog,
    private service: FarginServiceService,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.service.customerbulkResponse(this.merchantId).subscribe((res: any) => {
      this.bulkresponse = res.response;
      console.log(this.bulkresponse);
      this.dataSource = new MatTableDataSource(this.bulkresponse.reverse())
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })

    this.service.viewRole(this.roleId).subscribe((res: any) => {
      console.log(res);
      if (res.flag == 1) {
        this.getdashboard = res.response?.merchantSubPermission;
        if (this.roleId == 2) {
          this.valueresponse = 'Customer Status-Response';
        }
        else {
          for (let datas of this.getdashboard) {
            this.actions = datas.subPermissions

            if (this.actions == 'Customer Status-Response') {
              this.valueresponse = 'Customer Status-Response'
            }
          }
        }
      }
    })


  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  responseDownload(uploadId: any) {
    this.service.customerbulkbyId(uploadId).subscribe((res: any) => {
      this.responseData = res.response.jsonNode.data
      console.log(this.responseData);
      if (res.flag == 1) {
        let sno = 1;
        this.responseExcelData = [];
        this.responseData?.forEach((element: any) => {
          this.dataPush = [];
          this.dataPush.push(sno);
          this.dataPush.push(element?.response); sno++;
          this.responseExcelData.push(this.dataPush);
          console.log(this.responseExcelData);
        });
        this.responseExcel();
      } else {
        this.toastr.error(res.responseMessage)
      }
    })
  }

  responseExcel() {

    const header = ["S.No", "success"]

    const data = this.responseExcelData;
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Upload Response');

    worksheet.addRow([]);


    let headerRow = worksheet.addRow(header);

    headerRow.font = { bold: true };

    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' },
        bgColor: { argb: 'FF0000FF' },
      }

      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    });

    data.forEach((d: any) => {
      // console.log("row loop");

      let row = worksheet.addRow(d);
      let qty = row.getCell(1);
      let qty1 = row.getCell(2);
      let qty2 = row.getCell(3);
      let qty3 = row.getCell(4);


      qty.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty1.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty2.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty3.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }

    }
    );

    workbook.xlsx.writeBuffer().then((data) => {

      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });


      FileSaver.saveAs(blob, 'UploadResponse.csv');

    });
  }
}
