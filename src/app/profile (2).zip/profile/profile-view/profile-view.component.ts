import { Component, OnInit } from '@angular/core';
import { FarginServiceService } from '../../service/fargin-service.service';

@Component({
  selector: 'app-profile-view',
  templateUrl: './profile-view.component.html',
  styleUrl: './profile-view.component.css'
})
export class ProfileViewComponent implements OnInit {
  merchantId = localStorage.getItem('merchantId') || '';
  technicalTotalAmount=localStorage.getItem('technicalTotalAmount');
  gstAmount=localStorage.getItem('gstAmount');
  technicalAmount=localStorage.getItem('technicalAmount')
  technicalPayStatus=localStorage.getItem('technicalPayStatus')
  manualDetails: any;
  profilevalue: any;
  constructor(
    private service: FarginServiceService,
  ) { }

  ngOnInit(): void {
    console.log(this.technicalTotalAmount);
    console.log(this.gstAmount);
    console.log(this.technicalAmount);
    console.log(this.technicalPayStatus);
    
    // this.service.profileView(this.merchantId).subscribe((res:any)=>{
    //   this.profilevalue=res.response;
    //   console.log(this.profilevalue);
      
    // })
    
    

    
  
  }

}
