import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { Disclaimerpolicy } from '../../fargin-model/fargin-model.module';

@Component({
  selector: 'app-viewdisclaimer',
  templateUrl: './viewdisclaimer.component.html',
  styleUrl: './viewdisclaimer.component.css'
})
export class ViewdisclaimerComponent {
  viewdisclaimer: any;
  disclaimer: any;
  disclaimers: any;
  merchantId = localStorage.getItem('merchantId') || '';
  valuedisclaimer: any;
  getdashboard: any[] = [];
  actions: any;
  roleId: any = localStorage.getItem('roleId')
  merchantName = localStorage.getItem('merchantname') || '';
  Check: boolean=false;
  policyId: any;
  approvedstatus: any;
  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService, private router: Router) {
 
  }
 
 
  ngOnInit(): void {
 
    this.service.viewterm(this.merchantId).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewdisclaimer = res.response.EntityModel.disclaimer;
        this.policyId=res.response.EntityModel.policyId;
        this.approvedstatus=res.response.EntityModel.disclaimerApprovedStatus;
 
 
        //   for (let i = 0; i < this.viewdisclaimer.length; i++) {
        //     const element = this.viewdisclaimer[i];
        //     this.disclaimer = element.disclaimer;
        //   console.log(this.disclaimer)
 
        // }
 
      }
    });
    this.service.viewRole(this.roleId).subscribe((res: any) => {
      console.log(res);
      if (res.flag == 1) {
        this.getdashboard = res.response?.merchantSubPermission;
        if(this.roleId==2){
        this.valuedisclaimer = 'Disclaimer-View';
      }
      else {
        for (let datas of this.getdashboard) {
          this.actions = datas.subPermissions
          if (this.actions == 'Disclaimer-View') {
            this.valuedisclaimer = 'Disclaimer-View'
          }
        }
      }
    }
    })
 
  }
 
  select(check:any){
    this.Check=check;
    console.log(this.Check)
    }
 
    Accept(){
    let submitModel:Disclaimerpolicy={
      disclaimerApprovedStatus: 'approved',
      disclaimerApprovedBy: this.merchantName
    }
      this.service.DisclaimerPolicyUpdate(this.policyId,submitModel).subscribe((res:any)=>{
        if(res.flag==1){
          this.toastr.success(res.responseMessage)
          setTimeout(() => {
            window.location.reload()
          }, 500);
        }
      })
    }

}
