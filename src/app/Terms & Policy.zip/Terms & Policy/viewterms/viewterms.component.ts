import { Component, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { Termspolicy } from '../../fargin-model/fargin-model.module';

@Component({
  selector: 'app-viewterms',
  templateUrl: './viewterms.component.html',
  styleUrl: './viewterms.component.css'
})
export class ViewtermsComponent {
  viewterms: any;
  terms: any;
  termAndCondition: any;
  closebutton: boolean = false;
  displayTimer: boolean = true;
  display: any;
  ADD: boolean = false;
  Check: boolean=false;
 
  merchantId = localStorage.getItem('merchantId') || '';
  merchantName = localStorage.getItem('merchantname') || '';
  policyId: any;
  ApprovedStatus: any;
 
  constructor(private dialog:MatDialog,private service:FarginServiceService,private toastr:ToastrService, private router: Router) {
 
  }
 
 
  ngOnInit(): void {
   
    console.log(this.Check)
    this.service.viewterm(this.merchantId).subscribe((res: any) => {
      if(res.flag==1){
        this.viewterms = res.response.EntityModel.termAndCondition;
        this.policyId=res.response.EntityModel.policyId;
        this.ApprovedStatus=res.response.EntityModel.termsConditionApprovedStatus;
        console.log(  this.ApprovedStatus)
      //   for (let i = 0; i < this.viewterms.length; i++) {
      //     const element = this.viewterms[i];
      //     this.terms = element.terms;
      //   console.log(this.terms)
      //   this.termAndCondition = element.termAndCondition;
      //   console.log(this.termAndCondition)
 
      // }
    }  
    });
 
 
  }
 
 
  close() {
    window.location.reload()
  }
 
  select(check:any){
  this.Check=check;
  console.log(this.Check)
  }
 
  Accept(){
  let submitModel:Termspolicy={
    termsConditionApprovedStatus: 'approved',
    termsConditionApprovedBy: this.merchantName
  }
    this.service.TermsPolicyUpdate(this.policyId,submitModel).subscribe((res:any)=>{
      if(res.flag==1){
        this.toastr.success(res.responseMessage)
        setTimeout(() => {
          window.location.reload()
        }, 500);
      }
    })
  }
}
