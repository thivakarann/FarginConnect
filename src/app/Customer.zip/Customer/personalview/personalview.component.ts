import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FarginServiceService } from '../../service/fargin-service.service';
import { Location } from '@angular/common';
import { ChannelViewComponent } from '../channel-view/channel-view.component';
import { ActiveCustomer } from '../../fargin-model/fargin-model.module';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { LcopaddComponent } from '../lcopadd/lcopadd.component';
import { BouquetaddComponent } from '../bouquetadd/bouquetadd.component';
import { AddAlcotComponent } from '../add-alcot/add-alcot.component';

@Component({
  selector: 'app-personalview',
  templateUrl: './personalview.component.html',
  styleUrl: './personalview.component.css'
})
export class PersonalviewComponent {
  id: any;
  customerview: any;
  customerviewalcot: any
  customer: any;
  selectedTab: string = 'customer-info'; // Default to 'customer-info'
  items: any[] = []; // The array of items to paginate
  page: number = 1;
  page1: number = 1;
  page2: number = 1;
  page3: number = 1;
  page4: number = 1;

  term: any;
  selected: any;
  // selecteded: string = '5';
  dataSource: any;
  searchText: any;

  data: any;
  status: any;
  viewcustomer: any;
  alcotchannel: any;
  bouquetPlan: any;
  lcopChannel: any;
  transaction: any;
  showData: boolean = false;
  viewData: boolean = false;
  alcotlist: any;
  getdashboard: any[] = [];
  actions: any;
  roleId: any = localStorage.getItem('roleId')
  valuecustomerinfo: any;
  valuecustomerplan: any;
  valuecustomertransaction: any;
  customerId: any;
  isChecked: any;
  totalAmount: number = 0;
  totalbouqet: number = 0;
  totallcop: number = 0;
  overallAmount: number = 0;
  valuealcotadd: any;
  valuealcotstatus: any;
  valuebouqAdd: any;
  valuebouqStatus: any;
  valuelcopaddd: any;
  valuelcopstatus: any;

  selectTab(tab: string) {
    this.selectedTab = tab;
  }


  constructor(
    public service: FarginServiceService,
    private router: Router,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private ActivateRoute: ActivatedRoute, private location: Location

  ) { }

  ngOnInit(): void {


    this.ActivateRoute.queryParams.subscribe((param: any) => {
      this.id = param.Alldata;
    });

    this.service.ViewCustomerDetails(this.id).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewcustomer = res.response.customerdetail;
        this.alcotchannel = res.response.alcotList;
        this.bouquetPlan = res.response.bouquetList;
        this.lcopChannel = res.response.lcopList;
        this.customerId = res.response.customerdetail.customerId;
        let totalAmount = 0;
        const alcotList = res.response.alcotList;


        for (let i = 0; i < alcotList.length; i++) {
          totalAmount += alcotList[i].price;
        }

        this.totalAmount = totalAmount;
        this.viewData = true;


        let totalbouqet = 0;
        const bouquetList = res.response.bouquetList;

        for (let i = 0; i < bouquetList.length; i++) {
          totalbouqet += bouquetList[i].broadCasterId.amount;
        }

        this.totalbouqet = totalbouqet;
        this.viewData = true;


        let totallcop = 0;
        const lcopList = res.response.lcopList;

        for (let i = 0; i < lcopList.length; i++) {
          totallcop += lcopList[i].overallAmount;
        }

        this.totallcop = totallcop;

        this.viewData = true;
        this.overallAmount = this.totalAmount + this.totalbouqet + this.totallcop;
      }
      else {
        this.viewData = false;

      }

    })

    this.service.CustomerTransaction(this.id).subscribe((res: any) => {
      if (res.flag == 1) {
        this.transaction = res.response;
        this.showData = true;

      }
      else {
        this.showData = false
      }
    })


    this.service.viewRole(this.roleId).subscribe((res: any) => {
      console.log(res);
      if (res.flag == 1) {
        this.getdashboard = res.response?.merchantSubPermission;
        if (this.roleId == 2) {
          this.valuecustomerinfo = 'Customer-Customer Information';
          this.valuecustomerplan = 'Customer-Plan Details';
          this.valuecustomertransaction = 'Customer-Transaction';
          this.valuealcotadd = 'Customer-Alcot Add'
          this.valuealcotstatus = 'Customer-Alcot Status'
          this.valuebouqAdd = 'Customer-Bouquet Add'
          this.valuebouqStatus = 'Customer-Bouquet Status'
          this.valuealcotadd = 'Customer-LCOP Add'
          this.valuelcopstatus = 'Customer-LCOP Status'
        }
        else {
          for (let datas of this.getdashboard) {
            this.actions = datas.subPermissions
            if (this.actions == 'Customer-Customer Information') {
              this.valuecustomerinfo = 'Customer-Customer Information'
            }
            if (this.actions == 'Customer-Plan Details') {
              this.valuecustomerplan = 'Customer-Plan Details'
            }
            if (this.actions == 'Customer-Transaction') {
              this.valuecustomertransaction = 'Customer-Transaction'
            }
            if (this.actions == 'Customer-Alcot Add') {
              this.valuealcotadd = 'Customer-Alcot Status'
            }
            if (this.actions == 'Customer-Alcot Status') {
              this.valuealcotstatus = 'Customer-Alcot Status'
            }
            if (this.actions == 'Customer-Bouquet Add') {
              this.valuebouqAdd = 'Customer-Bouquet Add'
            }
            if (this.actions == 'Customer-Bouquet Status') {
              this.valuebouqStatus = 'Customer-Bouquet Status'
            }
            if (this.actions == 'Customer-LCOP Add') {
              this.valuealcotadd = 'Customer-LCOP Status'
            }
            if (this.actions == 'Customer-LCOP Status') {
              this.valuealcotstatus = 'Customer-LCOP Status'
            }
          }
        }
      }
    })
  }

  close() {
    this.location.back()
  }

  Viewchannels(id: any) {
    console.log('alcot', this.id)
    this.dialog.open(ChannelViewComponent, {
      enterAnimationDuration: "500ms",
      exitAnimationDuration: "1000ms",
      data: { value: id }
    })
  }


  addalcot() {
    this.dialog.open(AddAlcotComponent, {
      enterAnimationDuration: "500ms",
      exitAnimationDuration: "1000ms",
      data: { value: this.customerId }
    })
  }


  addbouquet() {
    this.dialog.open(BouquetaddComponent, {
      enterAnimationDuration: "500ms",
      exitAnimationDuration: "1000ms",
      data: { value: this.customerId }
    })
  }

  addLcop() {
    this.dialog.open(LcopaddComponent, {
      enterAnimationDuration: "500ms",
      exitAnimationDuration: "1000ms",
      data: { value: this.customerId }
    })
  }


  ActiveStatus(event: MatSlideToggleChange, id: any) {
    this.isChecked = event.checked;
    let submitmodel: ActiveCustomer = {
      activeStatus: this.isChecked ? 1 : 0,

    }

    this.service.CustomerPlanStatus(id, submitmodel).subscribe((res: any) => {
      console.log(res);
      this.toastr.success(res.responseMessage);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    });





  }

}