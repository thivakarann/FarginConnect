import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import * as XLSX from 'xlsx';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-customer-bulkupload',
  templateUrl: './customer-bulkupload.component.html',
  styleUrl: './customer-bulkupload.component.css'
})
export class CustomerBulkuploadComponent implements OnInit {
  merchantId: any = localStorage.getItem('merchantId');
  entityname: any = localStorage.getItem('entityname')
  customerformGroup: any = FormGroup;
  ExcelData: any;
  parsedJson: any;
  uploadFiles: any;
  file: File | null = null;
  arrayExcel: any[] = [];
  constructor(private dialog: MatDialog,
    private service: FarginServiceService,
    private toastr: ToastrService,
    private fb: FormBuilder,
  ) { }
  ngOnInit(): void {

    this.customerformGroup = this.fb.group({
      uploadFile: ['', Validators.required]
    })

  }
  get uploadFile() {
    return this.customerformGroup.get('uploadFile')
  }

  uploadBulkFile(event: any) {
    console.log('File upload initiated');
    this.file = event.target.files[0];

    if (!this.file) {
      console.error('No file selected');
      return;
    }

    const fileReader = new FileReader();
    fileReader.readAsBinaryString(this.file);

    fileReader.onload = (e) => {
      const rABS = !!fileReader.readAsArrayBuffer;
      const workbook = XLSX.read(fileReader.result, {
        type: rABS ? 'binary' : 'string',
      });

      const sheetName = workbook.SheetNames[0];
      this.arrayExcel = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

      // Optionally transform specific fields into arrays
      this.arrayExcel = this.arrayExcel.map((row: any) => ({
        ...row,
        channelName: Array.isArray(row.channelName) ? row.channelName : row.channelName.split(',').map((value:any) => value.trim()),
        planName: Array.isArray(row.planName) ? row.planName : row.planName.split(',').map((value:any)=>value.trim()),
        bouquetName: Array.isArray(row.bouquetName) ? row.bouquetName : row.bouquetName.split(',').map((value:any)=>value.trim()),
      }));

      console.log('Parsed Excel Data:', this.arrayExcel);
    };

    fileReader.onerror = (error) => {
      console.error('Error reading file:', error);
    };
  }
  
  submit() {
    if (this.arrayExcel.length) {
      console.log("check");
      
      this.service.customerAddBulk(this.merchantId, this.entityname, this.arrayExcel).subscribe((res: any) => {
     
      
        this.uploadFiles = res.responseMessage;
        console.log(this.uploadFiles);
    
        if (res.flag === 1) {
          this.toastr.success(res.responseMessage);
          this.dialog.closeAll();
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } else if (res.flag === 2) {
          this.toastr.success(res.responseMessage);
          this.dialog.closeAll();
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } else {
          this.toastr.error(res.responseMessage);
        }
      });
    }
    
  }
  

  close(){
    this.dialog.closeAll()
  }
}
