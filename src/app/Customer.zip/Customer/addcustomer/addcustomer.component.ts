import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FarginServiceService } from '../../service/fargin-service.service';
import { MatOption, MatSelect } from '@angular/material/select';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { CustomerCreate } from '../../fargin-model/fargin-model.module';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrl: './addcustomer.component.css'
})
export class AddcustomerComponent implements OnInit {
  myForm!: FormGroup;

  getadminname = localStorage.getItem('fullname');
  merchantId: any = localStorage.getItem('merchantId');
  Channels: any;
  @ViewChild('select1') select1: any = MatSelect;
  @ViewChild('select2') select2: any = MatSelect;
  @ViewChild('select3') select3: any = MatSelect;
  allSelected3 = false;
  allSelected2 = false;
  allSelected1 = false;
  ActivePlans: any;
  ActiveSetupbox: any;
  Activeserviceprovider: any;
  serviceId: any;
  ActiveLCOP: any;
  customerdetails: any;
  dataNeedToPush: any[] = [];
  emptyalcot: any[] = [];
  EmptyBouquet: any[] = [];
  constructor(private service: FarginServiceService, private location: Location, private toaster: ToastrService, private router: Router) {
  }
 
  ngOnInit(): void {
    this.myForm = new FormGroup({
      Name: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9 ]*$')
      ]),
 
      mobilenumber: new FormControl('', [
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('^[0-9]{10}$')
      ]),
      alternativemobilenumber: new FormControl('', [
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('^[0-9]{10}$')
      ]),
 
      contactEmail: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$')
      ]),
      oldDoorNo: new FormControl('', Validators.required),
      NewDoorNo: new FormControl(''),
 
      FlatNo: new FormControl(''),
      housename: new FormControl(''),
      Apartment: new FormControl(''),
      Streetname: new FormControl('', Validators.required),
 
      area: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9 ]*$')
      ]),
      landmark: new FormControl(''),
     
      country: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9 ]*$')
      ]),
 
 
      state: new FormControl('', Validators.required),
      city: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9 ]*$')
      ]),
      pincode: new FormControl('', [
        Validators.required,
        Validators.pattern("^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$")
 
      ]),

      lineType: new FormControl('', Validators.required),

      setupbox: new FormControl('', [
        Validators.required,
       
      ]),
      mso: new FormControl('', [
        Validators.required,
        
      ]),
      paidChannel: new FormControl('',),
      broadcaster: new FormControl('',),
      lcop: new FormControl('', Validators.required),
      advance: new FormControl('', Validators.required),
      amount: new FormControl('')

    });
 
    this.service.PaidChannels().subscribe((res: any) => {
      this.Channels = res.response;
    });
    this.service.ActiveBouquetePlans().subscribe((res: any) => {
      this.ActivePlans = res.response;
    });
    this.service.ActiveLcop(this.merchantId).subscribe((res: any) => {
      this.ActiveLCOP = res.response;
    });
    this.service.ActiveServiceProvider().subscribe((res: any) => {
      this.Activeserviceprovider = res.response;
 
    })
 
  }
 
 
  // First Form
 
  get Name() {
    return this.myForm.get('Name')
 
  }
  get mobilenumber() {
    return this.myForm.get('mobilenumber')
 
  }
 
  get alternativemobilenumber() {
    return this.myForm.get('alternativemobilenumber')
 
  }
 
  get contactEmail() {
    return this.myForm.get('contactEmail')
 
  }
  get oldDoorNo() {
    return this.myForm.get('oldDoorNo')
 
  }
  get NewDoorNo() {
    return this.myForm.get('NewDoorNo')
 
  }
 
 
  get FlatNo() {
    return this.myForm.get('FlatNo')
 
  }
  get Apartment() {
    return this.myForm.get('Apartment')
 
  }
  get housename() {
    return this.myForm.get('housename')
 
  }
  get Streetname() {
    return this.myForm.get('Streetname')
 
  }
 
 
  get area() {
    return this.myForm.get('area')
 
  }
  get landmark() {
    return this.myForm.get('landmark')
 
  }
  get country() {
    return this.myForm.get('country')
 
  }

  get lineType() {
    return this.myForm.get('lineType')
  }

  get state() {
    return this.myForm.get('state')
 
  }
  get city() {
    return this.myForm.get('city')
 
  }
  get pincode() {
    return this.myForm.get('pincode')
 
  }
 
  get setupbox() {
    return this.myForm.get('setupbox')
 
  }
  get mso() {
    return this.myForm.get('mso')
  }
 
  get paidChannel() {
    return this.myForm.get('paidChannel')
 
  }
  get broadcaster() {
    return this.myForm.get('broadcaster')
 
  }
  get lcop() {
    return this.myForm.get('lcop')
  }
  get advance() {
    return this.myForm.get('advance')
  }
  get amount() {
    return this.myForm.get('amount')
  }
  getServiceId(event: any,) {
    this.ActiveSetupbox = [];
    this.serviceId = event.target.value;
    console.log(this.serviceId)
    this.service.ActiveSetupBoxByMerchantId(this.merchantId,this.serviceId).subscribe((res: any) => {
      this.ActiveSetupbox = res.response;
    });
  }
 
  toggleAllSelection1() {
    if (this.allSelected1) {
      this.select1.options.forEach((item: MatOption) => item.select());
    } else {
      this.select1.options.forEach((item: MatOption) => item.deselect());
    }
  }
  toggleAllSelection2() {
    if (this.allSelected2) {
      this.select2.options.forEach((item: MatOption) => item.select());
    } else {
      this.select2.options.forEach((item: MatOption) => item.deselect());
    }
  }
  toggleAllSelection3() {
    if (this.allSelected3) {
      this.select3.options.forEach((item: MatOption) => item.select());
    } else {
      this.select3.options.forEach((item: MatOption) => item.deselect());
    }
  }
 
  submit() {
    let submitModel: CustomerCreate = {
      area: this.area?.value,
      customerName: this.Name?.value,
      countryName: this.country?.value,
      stateName: this.state?.value,
      pincodeName: this.pincode?.value,
      freeLine: this.lineType?.value,
      emailAddress: this.contactEmail?.value,
      alterMobileNumber: this.alternativemobilenumber?.value,
      apartmentName: this.Apartment?.value || "-",
      doorNumber: this.oldDoorNo?.value || "-",
      flatNumber: this.FlatNo?.value || "-",
      blockNumber: this.NewDoorNo?.value || "-",
      landmark: this.landmark?.value || "-",
      age: '-',
      streetName: this.Streetname?.value,
      mobileNumber: this.mobilenumber?.value,
      houseName: this.housename?.value || "-",
      merchantId: this.merchantId,
      alcotId: this.paidChannel?.value || this.emptyalcot,
      bouquetId: this.broadcaster?.value || this.EmptyBouquet,
      lcopId: this.lcop?.value,
      stbId: this.setupbox?.value,
      cityName: this.city?.value,
      advanceStatus: this.advance?.value,
      advanceAmount: this.amount?.value,
      createdBy: this.getadminname
    }
    this.service.OnboardCustomer(submitModel).subscribe((res: any) => {
      if (res.flag == 1) {
        this.customerdetails = res.response;
        this.toaster.success(res.responseMessage);
        this.router.navigateByUrl('dashboard/view-customer')
        setTimeout(() => {
          window.location.reload()
        }, 500);

      }
      else {
        this.toaster.error(res.responseMessage)
      }
    })
  }
 
  close() {
    this.location.back()
  }
}
