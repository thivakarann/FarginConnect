import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Workbook } from 'exceljs';
import FileSaver from 'file-saver';
import moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { ActiveCustomer, Statusadmin } from '../../fargin-model/fargin-model.module';
import { FarginServiceService } from '../../service/fargin-service.service';
import { CustomerBulkuploadComponent } from '../customer-bulkupload/customer-bulkupload.component';

@Component({
  selector: 'app-viewcustomer',
  templateUrl: './viewcustomer.component.html',
  styleUrl: './viewcustomer.component.css'
})
export class ViewcustomerComponent {
  dataSource: any;
  displayedColumns: string[] =
    [
      "sno",
      "name",
      "mso",
      "setupbox",
      "mobilenumber",
      "email",
      "status",
      "edit",
      "View",
      "createdBy",
      "createdDateTime",
      "modifiedBy",
      "modifiedDateTime"
    ]
  showcategoryData: boolean = false;
  errorMsg: any;
  responseDataListnew: any = [];
  response: any = [];
  merchantid: any = localStorage.getItem('merchantId')
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  customer: any;
  admin: any;
  isChecked: any;
  date1: any;
  date2: any;
  viewcustomerdetailsbymerchant: any;
  viewcustomer: any;
  alcotchannel: any;
  bouquetPlan: any;
  lcopChannel: any;
  values: any[] = [];
  values1: any[] = [];
  values2: any[] = [];

  datas: any[] = [];
  datas1: any[] = [];
  datas2: any[] = [];
  valueCustomerAdd: any;
  valueCustomerExport: any;
  valueCustomerEdit: any;
  valueCustomerView: any;
  valueCustomerStatus: any;
  getdashboard: any[] = [];
  actions: any;
  roleId: any = localStorage.getItem('roleId')
valuecustomerimport: any;
valuecustomerupload: any;


  constructor(private dialog: MatDialog, private service: FarginServiceService, private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
    // ViewCustomerByMerchantDetails
    
    this.service.customerbulkViewall(this.merchantid).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewcustomerdetailsbymerchant = res.response;
        this.viewcustomerdetailsbymerchant.reverse();
        this.dataSource = new MatTableDataSource(this.viewcustomerdetailsbymerchant);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    })
    this.service.viewRole(this.roleId).subscribe((res: any) => {
      console.log(res);
      if (res.flag == 1) {
        this.getdashboard = res.response?.merchantSubPermission;
        if(this.roleId==2){

        this.valueCustomerAdd = 'Customer-Add';
        this.valueCustomerEdit = 'Customer-Edit'
        this.valueCustomerExport = 'Customer-Export'
        this.valueCustomerStatus = 'Customer-Status'
        this.valueCustomerView = 'Customer-View'
        this.valuecustomerimport='Customer-Import'
        this.valuecustomerupload='Customer-Upload File'
      }
      else {
        for (let datas of this.getdashboard) {
          this.actions = datas.subPermissions

          if (this.actions == 'Customer-Add') {
            this.valueCustomerAdd = 'Customer-Add'
          }
          if (this.actions == 'Customer-Edit') {
            this.valueCustomerEdit = 'Customer-Edit'
          }
          if (this.actions == 'Customer-Export') {
            this.valueCustomerExport = 'Customer-Export'
          }
          if (this.actions == 'Customer-Status') {
            this.valueCustomerStatus = 'Customer-Status'
          }
          if (this.actions == 'Customer-View') {
            this.valueCustomerView = 'Customer-View'
          }
          if(this.actions=='Customer-Import'){
            this.valuecustomerimport='Customer-Import'
          }
          if(this.actions=='Customer-Upload File'){
            this.valuecustomerupload='Customer-Upload File'
          }
        }
      }

   } })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  add() {
    this.router.navigateByUrl('dashboard/add-customer');
  }
  edit(id: any) {
    this.datas = [];
    this.datas1 = [];
    this.datas2 = [];

    this.service.ViewCustomerDetails(id).subscribe((res: any) => {
      if (res.flag == 1) {
        this.viewcustomer = res.response;
        this.alcotchannel = res.response.alcotList;
        console.log(this.alcotchannel)
        for (let datas of this.alcotchannel) {
          console.log(datas)
          this.values.push(datas.alcotId)
        }

        this.bouquetPlan = res.response.bouquetList;
        console.log(this.bouquetPlan)
        for (let datas1 of this.bouquetPlan) {
          console.log(datas1)

          this.values1.push(datas1.bouquetId)
        }

        this.lcopChannel = res.response.lcopList;
        console.log(this.lcopChannel)
        for (let datas2 of this.lcopChannel) {
          console.log(datas2)

          this.values2.push(datas2.lcopId)
        }

        this.router.navigate([`dashboard/editcustomer/${id}`], {
          queryParams: {
            Alldata: id,
            Alcot: this.values,
            Bouquet: this.values1,
            LCOP: this.values2


          },


        })

      }

    });


    console.log(id);
  }

  Viewdata(id: any) {
    this.router.navigate([`dashboard/personal-view/${id}`], {
      queryParams: { Alldata: id },
    });
    console.log(id);
  }






  ActiveStatus(event: MatSlideToggleChange, id: any) {
    this.isChecked = event.checked;
    let submitmodel: ActiveCustomer = {
      activeStatus: this.isChecked ? 1 : 0,

    }

    this.service.ActiveStatusCustomer(id, submitmodel).subscribe((res: any) => {
      console.log(res);
      this.toastr.success(res.responseMessage);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    });





  }

  setuphistory() {

    // this.router.navigate([`dashboard/setupboxhistory/${id}`], {
    //   queryParams: { Alldata: id },
    // });

    this.router.navigate([`dashboard/setupboxhistory`], {
      // queryParams: { Alldata: id },
    })
  }
  exportexcel() {
    console.log('check');
    let sno = 1;
    this.responseDataListnew = [];
    this.viewcustomerdetailsbymerchant.forEach((element: any) => {
      let createdate = element.createdDateTime;
      this.date1 = moment(createdate).format('DD/MM/yyyy-hh:mm a').toString();

      // let moddate = element.modifiedDateTime;
      // this.date2 = moment(moddate).format('DD/MM/yyyy-hh:mm a').toString();

      this.response = [];
      this.response.push(sno);
      this.response.push(element?.customerName);
      this.response.push(element?.stbId.service.serviceProviderName);
      this.response.push(element?.stbId.setupBoxNumber);
      this.response.push(element?.mobileNumber);
      this.response.push(element?.emailAddress);
      this.response.push(element?.createdBy);
      this.response.push(this.date1);
      this.response.push(element?.modifiedBy);

      if (element?.modifiedDateTime) {
        let issuedatas = element?.modifiedDateTime;
        this.date2 = moment(issuedatas).format('yyyy-MM-DD hh:mm a').toString();
        this.response.push(this.date2);
      }
      else {
        this.response.push('');
      }




      sno++;
      this.responseDataListnew.push(this.response);
    });
    this.excelexportCustomer();
  }

  excelexportCustomer() {
    // const title='Business Category';
    const header = [
      "S.No",
      "Customer Name",
      "Service Provider",
      "Setup box Number",
      "Mobile Number",
      "Email",
      "Created By",
      "Created At",
      "Modified By",
      "Modified At",
    ]


    const data = this.responseDataListnew;
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Customer Onboard');
    // Blank Row
    // let titleRow = worksheet.addRow([title]);
    // titleRow.font = { name: 'Times New Roman', family: 4, size: 16, bold: true };


    worksheet.addRow([]);
    let headerRow = worksheet.addRow(header);
    headerRow.font = { bold: true };
    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' },
        bgColor: { argb: 'FF0000FF' },

      }

      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    });

    data.forEach((d: any) => {
      // console.log("row loop");

      let row = worksheet.addRow(d);
      let qty = row.getCell(1);
      let qty1 = row.getCell(2);
      let qty2 = row.getCell(3);
      let qty3 = row.getCell(4);
      let qty4 = row.getCell(5);
      let qty5 = row.getCell(6);
      let qty6 = row.getCell(7);
      let qty7 = row.getCell(8);
      let qty8 = row.getCell(9);
      let qty9 = row.getCell(10);



      qty.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty1.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty2.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty3.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty4.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty5.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty6.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty7.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty8.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      qty9.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }


    }
    );

    // worksheet.getColumn(1).protection = { locked: true, hidden: true }
    // worksheet.getColumn(2).protection = { locked: true, hidden: true }
    // worksheet.getColumn(3).protection = { locked: true, hidden: true }


    workbook.xlsx.writeBuffer().then((data: any) => {

      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });


      FileSaver.saveAs(blob, 'Customer Onboard.xlsx');

    });
  }




  // Customer Bulk upload

  // openExcel() {
  //   let sno = 1;
  //   this.responseDataListnew = [];
  //   this.excelexportDetails();
  // }
  excelexportDetails() {
    const header = [
        "customerName",
        "area",
        "cityName",
        "pincodeName",
        "stateName",
        "countryName",
        "emailAddress",
        "alterMobileNumber",
        "apartmentName",
        "flatNumber",
        "blockNumber",
        "doorNumber",
        "landmark",
        "houseName",
        "age",
        "advanceStatus",
        "advanceAmount",
        "streetName",
        "mobileNumber",
        "setupBoxNumber",
        "channelName",
        "planName",
        "bouquetName"
    ];
    
    const data = this.responseDataListnew;

    // Prepare CSV content
    const csvContent = [];

    // Add header to CSV
    csvContent.push(header.map(item => `"${item}"`).join(','));

    data.forEach((d: any) => {
        // Access the first element and remove single quotes if present
        const channelNames = Array.isArray(d.channelName) ? d.channelName[0].replace(/'/g, '') : d.channelName;
        const planNames = Array.isArray(d.planName) ? d.planName[0].replace(/'/g, '') : d.planName;
        const bouquetNames = Array.isArray(d.bouquetName) ? d.bouquetName[0].replace(/'/g, '') : d.bouquetName;

        // Prepare the row data with double quotes
        const rowData = [
            d.customerName,
            d.area,
            d.cityName,
            d.pincodeName,
            d.stateName,
            d.countryName,
            d.emailAddress,
            d.alterMobileNumber,
            d.apartmentName,
            d.flatNumber,
            d.blockNumber,
            d.doorNumber,
            d.landmark,
            d.houseName,
            d.age,
            d.advanceStatus,
            d.advanceAmount,
            d.streetName,
            d.mobileNumber,
            d.setupBoxNumber,
            channelNames,
            planNames,
            bouquetNames
        ].map(item => `"${item}"`); // Wrap each item in double quotes

        csvContent.push(rowData.join(','));
    });

    // Create a Blob and save as CSV
    const blob = new Blob([csvContent.join('\n')], { type: 'text/csv;charset=utf-8;' });
    FileSaver.saveAs(blob, 'Customer.csv');
}



  create(){
    this.dialog.open(CustomerBulkuploadComponent,
      { 
         disableClose: true,
        enterAnimationDuration: '1000ms',
        exitAnimationDuration: '1000ms',
      }
    )
  }
}
